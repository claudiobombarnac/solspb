sfljTSE
Copyrigth (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
Released under GNU General Public License.

The SFL Java Trading System Enviroment is a java application built on KISS principle ( Keep It Simple,Stupid ) 
and its aim is to provide a fast and platform indipendent infrastructure to develop and execute 
trading systems.

- importing quotes 
- trading strategy
- back testing, statistics, reports
- signal's alarm (mail,sms,etc)
- automated orders
- graph (chart,equity,etc)
