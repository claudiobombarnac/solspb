/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.data;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 * @title		: DB        
 * @description	: Simple way to manage data, It uses hsqldb,
 *                standalone persistent db application. 
 * @date		: 4-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class DB {

    // db connection
    Connection conn;

    /**
     * Constructor
     * @param db_file_name
     * @param user
     * @param password
     * @throws Exception
     */
    public DB(String db_file_name,String user,String password) throws Exception {    // note more general exception

        // Load the HSQL Database Engine JDBC driver
        // hsqldb.jar should be in the class path or made part of the current jar
        Class.forName("org.hsqldb.jdbcDriver");

        // connect to the database.   This will load the db files and start the
        // database if it is not alread running.
        conn = DriverManager.getConnection("jdbc:hsqldb:"+ db_file_name,user,password);
    }

    /**
     * Shutdown database
     * @throws SQLException
     */
    public void shutdown() throws SQLException {

        Statement st = conn.createStatement();
        st.execute("SHUTDOWN");
        conn.close();
    }


    /**
     * Execute a query, usually a SELECT and returns the resultset
     * @param expression
     * @return ResultSet
     * @throws SQLException
     */
    public synchronized ResultSet query(String expression) throws SQLException {

        Statement st = null;
        ResultSet rs = null;

        st = conn.createStatement();
        rs = st.executeQuery(expression);
        st.close();
           
        return rs;
    }


    /**
     * Execute an expression, usually a CREATE,DROP,INSERT and UPDATE
     * @param expression
     * @throws SQLException
     */
    public synchronized void update(String expression) throws SQLException {

        Statement st = null;

        st = conn.createStatement();
        int i = st.executeUpdate(expression);

        if (i == -1) {
            System.out.println("db error : " + expression);
        }

        st.close();
    }

    
    /**
     * Main, use it only for test this class
     */
    public static void main(String[] args) {

        DB db = null;

        try {
            db = new DB("data/valute","sa","");
        } catch (Exception ex1) {
            System.out.println("Could not start database!");
            return;
        }
        

        try {
            //  create a table
            db.update("CREATE CACHED TABLE employee ( id INTEGER IDENTITY, fullname VARCHAR(256), role VARCHAR(256), salary DOUBLE)");
        } catch (SQLException ex2) {
            // do nothing
        }
     

        try {

            // add some records to table of employee of a typical italian company...
            db.update("INSERT INTO employee(fullname,salary,role) VALUES('John Doe', 2600, 'idiot')");
            db.update("INSERT INTO employee(fullname,salary,role) VALUES('Foo Bar', 3200, 'superIdiot')");
            db.update("INSERT INTO employee(fullname,salary,role) VALUES('Lucio Luzzatto', 0, 'nobel')");
            
            System.out.println("A sample of famous italian's meritocracy");
            System.out.println("Full Name\t\tRole\t\tSalary");
            // do a query
            ResultSet rs = db.query("SELECT * FROM employee ORDER BY salary");
            while (rs.next()){
                System.out.println(rs.getString("fullname")+"\t\t "+rs.getString("role")+"\t\t "+rs.getString("salary"));
            }
                
            // finished, shutdown db
            db.shutdown();
        } catch (SQLException ex3) {
            ex3.printStackTrace();
        }
    }    // main()
}    // class Testdb
