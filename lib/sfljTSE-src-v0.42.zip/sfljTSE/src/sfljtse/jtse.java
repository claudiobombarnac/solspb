/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse;

import java.io.FileInputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;

import sfljtse.quotes.CsvImport;
import sfljtse.quotes.DBQuotes;
import sfljtse.settings.Settings;
import sfljtse.utils.Common;


/**
 * @title		: sfltse       
 * @description	: Main class for the java Trading System Enviroment  
 * @date		: 26-Jul-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class jtse {

	final static String VERSION	= "v0.42";
	final static String EMAIL	= "a.sfolcini@gmail.com";
	final static String AUTHOR	= "Alberto Sfolcini <"+EMAIL+">";
	
    // input prameters
	private final static String PARM_IMPORT	           = "--import";
	private final static String PARM_HELP	           = "--help";
	private final static String PARM_SYSTEM	           = "--system";
    private final static String PARM_INFO              = "--info";
    private final static String PARM_SYMBOLS           = "--symbolList";
    private final static String PARM_SYSTEMS           = "--systemList";
    private final static String PARM_VERBOSE           = "--verbose";
    private final static String PARM_SYMBOL            = "--symbol";
    private final static String PARM_SYMBOL_REMOVE     = "--remove";
    private final static String PARM_SYMBOL_RENAME     = "--rename";
    private final static String PARM_TEST              = "--test";
	
    // where system classes are stored
	private final static String SYSTEMS_REPO = "sfljtse.systems.";
    
	public static void main(String[] args) {
		
		System.out.println("SFL Java Trading Systems Enviroment "+VERSION);
		System.out.println("Copyright � 2005 "+AUTHOR);
        System.out.println("Released under GNU General Public License.\n");

		
		if (args.length>0) {
		    		    
			/* HELP */
			if (args[0].equalsIgnoreCase(PARM_HELP)) {
				showUsage();
			}
			
			/* IMPORT */
			if (args[0].equalsIgnoreCase(PARM_IMPORT)) {
		       if (args.length>=3){
		           // skip first line,exit on error and replace old quotes
                   new CsvImport(args[1],args[2],args[3]);               
               }else {
                   System.out.println("Parameters missing!");
                   showUsage();
               }
			}

            /* SYSTEM */
            if (args[0].equalsIgnoreCase(PARM_SYSTEM)) {
                if (args.length==3)
                    loadSystem(args[1],args[2]);
                else {
                        System.out.println("Parameters missing!");
                        showUsage();
                    }
                    
            }   

            /* SYSTEM INFO*/
            if (args[0].equalsIgnoreCase(PARM_INFO)) {
                if (args.length==2)
                    showSystemInfo(args[1]);
                else {
                    System.out.println("Parameters missing!");
                    showUsage();
                }
                    
            }   

            /* SYMBOLS LIST*/
            if (args[0].equalsIgnoreCase(PARM_SYMBOLS)) {
                if (args.length==1)
                    showSymbols();
                else {
                    System.out.println("Parameters missing!");
                    showUsage();
                }                    
            }   

            /* SYMBOL MANAGMENT (remove,rename)*/
            if (args[0].equalsIgnoreCase(PARM_SYMBOL)) {
                if (args.length>=2){
                    if (args[1].equalsIgnoreCase(PARM_SYMBOL_REMOVE))
                        symbolRemove(args[2]);
                    if (args[1].equalsIgnoreCase(PARM_SYMBOL_RENAME))
                        symbolRename(args[2],args[3]);
                }
                else {
                    System.out.println("Parameters missing!");
                    showUsage();
                }
                    
            }   
            

            /* SYSTEM LIST*/
            if (args[0].equalsIgnoreCase(PARM_SYSTEMS)) {
                if (args.length==1)
                        showSystemList(false);
                else
                   if (args.length==2) {
                       if (args[1].equalsIgnoreCase(PARM_VERBOSE))
                           showSystemList(true);
                       else
                           showSystemList(false);
                   } else {
                       System.out.println("Parameters missing!");
                       showUsage();
                }                    
            }   
            
            
			/* TEST */
			if (args[0].equalsIgnoreCase(PARM_TEST)) {
				test();
			}
			
		} else {
			showUsage();
		}
	}
	
	/**
	 * Display Usage
	 */
	private static void showUsage() {
		System.out.println("\nUSAGE:");
		System.out.println("\t"+jtse.class+" [PARAMS]");
		System.out.println("PARAMS:");
		System.out.println("\t"+PARM_HELP+"            : displays what you are reading...");
		System.out.println("\t"+PARM_IMPORT+"          : filename.csv filename.xml symbol");
        System.out.println("\t"+PARM_SYSTEM+"          : system_name system-config.xml");
        System.out.println("\t"+PARM_INFO+"            : system_name");
        System.out.println("\t"+PARM_SYSTEMS+"      : displays systems list [--verbose]");
        System.out.println("\t\t"+PARM_VERBOSE+" : display verbose system list");
        System.out.println("\t"+PARM_SYMBOLS+"      : shows symbols list");
        System.out.println("\t"+PARM_SYMBOL+"          : [--rename|--remove] symbol");
        System.out.println("\t\t"+PARM_SYMBOL_REMOVE+"  : symbol");
        System.out.println("\t\t"+PARM_SYMBOL_RENAME+"  : symbol newSymbolName");
		System.out.println("\t"+PARM_TEST+"\t          : for developers only");
		
	}
	
	
	/**
	 * Loads system's class and execute it
	 */
	private static void loadSystem(String systemName,String symbol) {
	    	    
        systemName = SYSTEMS_REPO + systemName;
        Class[] cArgs = new Class[1];
        cArgs[0] = String.class;

        try {
            Class aClass = Class.forName(systemName);
            Class[] argumentTypes = { java.lang.String.class };
            Constructor oneArgument = null;
            try {
                oneArgument = aClass.getConstructor( argumentTypes );
            } catch (SecurityException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            } catch (NoSuchMethodException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            Object[] arguments = { symbol };
            try {
                oneArgument.newInstance( arguments );
            } catch (IllegalArgumentException e2) {
                // TODO Auto-generated catch block
                e2.printStackTrace();
            } catch (InstantiationException e2) {
                // TODO Auto-generated catch block
                e2.printStackTrace();
            } catch (IllegalAccessException e2) {
                // TODO Auto-generated catch block
                e2.printStackTrace();
            } catch (InvocationTargetException e2) {
                // TODO Auto-generated catch block
                e2.printStackTrace();
            }
        
        
        } catch (ClassNotFoundException e) {
            System.out.println("System NOT found!");        
        }


        
	}
	
	/**
     * Shows System info
     * @param systemName
	 */
    private static void showSystemInfo(String systemName){

            Class aClass = null;

            try {
                aClass = Class.forName(SYSTEMS_REPO+systemName);
                try {
                    aClass.newInstance();
                } catch (InstantiationException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            } catch (ClassNotFoundException e) {
                System.out.println("System NOT found!");
            }
    
        
    }
	
    
    /**
     * 
     * Shows Symbols
     */
    private static void showSymbols() {
        
        DBQuotes myQuotes = new DBQuotes(false);
        LinkedList symbol = myQuotes.getAllSymbols();
        String[] array = new String[3];
        
        System.out.println("SYMBOL\t| FULLNAME\t| GROUP\t| NOTE");
        for (int i=0;i<symbol.size();i++){
            array = (String[]) symbol.get(i);
            System.out.println(array[0]+"\t"+array[1]+"\t"+array[2]);
        }
        
        myQuotes.closeDB();
                
    }
	
    /**
     * Remove symbol from db
     * @param symbol
     */
    private static void symbolRemove(String symbol){
        DBQuotes myQ = new DBQuotes(false);
        if (myQ.deleteSymbol(symbol)) 
            System.out.println("Symbol "+symbol+" removed from database.");
        else
            System.out.println("Cannot remove symbol "+symbol+" from database.");
        myQ.closeDB();
    }

    /**
     * Rename symbol from db
     * @param symbol
     * @param newName 
     */
    private static void symbolRename(String symbol,String newName){
        DBQuotes myQ = new DBQuotes(false);
        if (myQ.renameSymbol(symbol,newName)) 
            System.out.println("Symbol "+symbol+" renamed to "+newName);
        else
            System.out.println("Cannot rename symbol "+symbol+" to "+newName);
        myQ.closeDB();
    }


    /**
     * Shows systems list
     * @param fullList boolean if true display system name and its properties
     *        else displays only the name
     */
    private static void showSystemList(boolean fullList){
        
        // THIS METHOD DOES NOT WORK IF THE PROGRAM RUNS INSIDE IDE ENVIROMENT
        // it needs jar file to work properly! 
        
        String repo = SYSTEMS_REPO.replace(".","/");
        String system = "";
        String fname = Common.getJarFileName(Settings.getProperty("WorkingDir")); 
        if (fname.trim().equals("")){
            System.out.println("WorkinDir is not configured in properties file!");
            return;
        }
        
        try {
             JarInputStream jis = new JarInputStream(new FileInputStream(fname));
             
             // Print the attributes for each jar entry.
             while (true) {
                 final JarEntry je = jis.getNextJarEntry();
                 if (je==null) break;
                 //System.out.println(je.toString());
                 if (je.toString().contains(repo))
                     system = je.toString().substring(repo.length());
                 if (system.contains(".class")){
                     system = system.substring(0,system.length()-6);
                     // strip ISystem.class that's an Interface and do not interest end users
                     if (!system.contains(("/"))){
                         System.out.println("["+system+"]");
                         if (fullList) showSystemInfo(system);
                     }
                 }
                     
             }
        jis.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        
    }
    
	/**
	 * 
	 * TEST method
	 */
	private static void test() {
             
        System.out.println("Gnu's Not Unix!");
				
	}
	
	
}
