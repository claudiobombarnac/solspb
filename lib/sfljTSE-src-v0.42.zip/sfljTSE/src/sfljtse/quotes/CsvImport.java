/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.quotes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.Locale;

import sfljtse.quotes.DBQuotes;
import sfljtse.utils.Common;
import sfljtse.utils.Timer;
import sfljtse.xml.ReadXML;
import sfljtse.settings.XML;



/**
 * @title		: CsvImport       
 * @description	: Imports quotes from CSV file format 
 * @date		: 4-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class CsvImport {

		private BufferedReader in=null;  
		private String line	= "";
        private ReadXML xml;
		
		private String xmlFile;
        private String symbol;
        private String csvFile	= "";
		private String	separator = ",";	
        private String[] strValues;
		private int fields 	= 0;
		private boolean	skip_firstline 	= true;
		private boolean exit_on_error 	= true;
		private boolean debug	= false;

        /* set false if you want to delete all old quotes before start to import new ones */
        private boolean update_quotes = false;
		
        /**
         * Constructor
         * Skip first line and replace old quotes, exit on error
         * @param csvFile
         * @param xmlFile
         * @param symbol
         */
        public CsvImport(String csvFile,String xmlFile,String symbol){    
            this.csvFile    = csvFile;
            this.xmlFile    = xmlFile;
            this.symbol     = symbol;
                     
            this.skip_firstline = true;
            this.exit_on_error  = true;
            this.debug  = false;
            this.update_quotes = false;
            loadConfiguration();
            startImport();
        }   

        
        /**
         * Constructor 2
         * Exit on error
         * @param csvFile
         * @param xmlFile
         * @param symbol
         * @param skipFirstLine
         * @param update
         */
        public CsvImport(String csvFile,String xmlFile,String symbol,boolean skipFirstLine,boolean update){    
            this.csvFile    = csvFile;
            this.xmlFile    = xmlFile;
            this.symbol     = symbol;
                     
            this.skip_firstline = skipFirstLine;
            this.exit_on_error  = true;
            this.debug  = false;
            this.update_quotes = update;
            loadConfiguration();
            startImport();
        }   

        /**
         * Constructor 3
         * @param csvFile
         * @param xmlFile
         * @param symbol
         * @param skipFirstLine
         * @param update
         * @param exitOnError
         */
        public CsvImport(String csvFile,String xmlFile,String symbol,boolean skipFirstLine,boolean update,boolean exitOnError){    
            this.csvFile    = csvFile;
            this.xmlFile    = xmlFile;
            this.symbol     = symbol;
                     
            this.skip_firstline = skipFirstLine;
            this.exit_on_error  = exitOnError;
            this.debug  = false;
            this.update_quotes = update;
            loadConfiguration();
            startImport();
        }   


        /**
         * Loads value from xmlfile
         *
         */
        private void loadConfiguration(){
            
            File f = new File(xmlFile);
            if (f.exists()){
                xml = new ReadXML(xmlFile);    
            } else {
                System.out.println("Cannot find file "+xmlFile+", please check it out and try again!");
                System.exit(1);
            }       
            
            this.separator = xml.getValueOf(XML.tag_FORMAT,XML.tag_FORMAT_SEPARATOR);
            strValues = new String[xml.getValuesOf(XML.tag_FIELDS,XML.tag_FIELDS_FIELD).length];
            this.strValues = xml.getValuesOf(XML.tag_FIELDS,XML.tag_FIELDS_FIELD);
            this.fields    = strValues.length;
     
        }

        
        
        /**
         * Import file
         */
        private void startImport() {
			// lines
			int 	lines  = 0;
			String date 	= "0";
			String time		= "0";
			String open 	= "0";
			String close 	= "0";
			String high  	= "0";
			String low		= "0";
			String volume	= "0";
			String openI	= "0";
			String dd		= null;
			String mm		= null;
			String yyyy		= null;
			
			try {
				in = new BufferedReader(new FileReader(csvFile));
			} catch (FileNotFoundException e) {
				System.out.println("File "+csvFile+" not found!");
				e.printStackTrace();
                System.exit(1);
			}	
	
			
			// fireup database connection
			DBQuotes quotes = new DBQuotes(true);
			String values[] = new String[50];

            // start timer
            Timer timer = new Timer();
            timer.startTimer();
            
            
            
			/* if !update_quotes */
			if (!update_quotes) {
				if (quotes.deleteSymbol(symbol)) {
					if (debug) System.out.println("Error while deleting old quotes");
				} else {
					if (debug) System.out.println("Deleting old quotes done.");
				}
			}
			
			/* insert ticker into db */
			if (quotes.insertSymbol(symbol,"","","0")) {
				if (debug) System.out.println("Stock Added");
			} else {
				System.out.println("Error while adding stock ticker into database");
				if (exit_on_error)
					System.exit(1);
			}
			
			
			// reading csv
			try {
				while ((line = in.readLine()) != null) {
					lines++;
					if (debug) System.out.println("Line "+lines+"="+line);
					
					
					// check for comments '<!'
					if (line.substring(0,2).equalsIgnoreCase("<!")) {
						// this line is a comment, please ignore it
						System.out.println("Found comment row, skipped.");
					} else {			
						if (lines==1&&skip_firstline) {
							System.out.println("First line skipped.");
						} else {
							// for each field
							for (int i=1;i<fields+1;i++) {
								try {
									if (i==1)
										line = line.substring(0,line.length());
									else
										line = line.substring(line.indexOf(separator)+1,line.length());
								} catch (Exception e) {
									System.out.println("Found error in line number "+lines);
									if (exit_on_error) 
										System.exit(1);
								}
								if (i==fields) {
									String field = line.substring(0,line.length());
									if (field=="") field="0";
									if (debug) System.out.println("FIELD "+i+"="+field);
									values[i] = field;
								}
								else {
									String field = line.substring(0,line.indexOf(separator));
									if (field=="") field="0";
									if (debug) System.out.println("FIELD "+i+"="+field);
									values[i] = field;							
								}
							} // end for


                            // gets values
                            for (int i=0;i<strValues.length;i++){
                                if (strValues[i].equalsIgnoreCase(XML.quote_DATE))
                                    date = values[i+1];
                                if (strValues[i].equalsIgnoreCase(XML.quote_TIME))
                                    time = values[i+1];
                                if (strValues[i].equalsIgnoreCase(XML.quote_OPEN))
                                    open = values[i+1].replaceAll(",",".");
                                if (strValues[i].equalsIgnoreCase(XML.quote_CLOSE))
                                    close = values[i+1].replaceAll(",",".");
                                if (strValues[i].equalsIgnoreCase(XML.quote_HIGH))
                                    high = values[i+1].replaceAll(",",".");
                                if (strValues[i].equalsIgnoreCase(XML.quote_LOW))
                                    low = values[i+1].replaceAll(",",".");
                                if (strValues[i].equalsIgnoreCase(XML.quote_VOLUME))
                                    volume = values[i+1].replaceAll(",",".");
                                if (strValues[i].equalsIgnoreCase(XML.quote_OPENINT))
                                    openI = values[i+1].replaceAll(",",".");
                            }
                            
                            
                            
                            if (debug)
                                System.out.println(date+","+time+","+open+","+close+","+high+","+low+","+volume);

                            // check date field and convert if needed
                            String dateFormat = xml.getValueOf(XML.tag_FORMAT,XML.tag_FORMAT_DATEFORMAT);
                            Date tmpDate = new Date();
                            
                            try {
                                tmpDate = Common.stringToDate(date.trim(),dateFormat,Locale.US);                                   
                                // converts data to ISO format
                                date = Common.Date2ISO(tmpDate);
                            
                            } catch (Throwable e) {
                                System.out.println("Cannot convert date "+date.toString()+" check you xml configuration file and set the right DateFormat!");
                                System.exit(1);
                            }
                            
                            /* insert quotes into db */
							if (quotes.insertQuotes(symbol,date,time,open,close,high,low,volume,openI)) {
								if (debug) System.out.println("ADDED");
							} else {
								System.out.println("Error while adding record into database");
								if (exit_on_error)
								System.exit(1);
							}
							
							//DEBUG Info					
							if (debug) {
								System.out.println("Date\t= "+date);
								System.out.println("Time\t= "+time);
								System.out.println("Open\t= "+open);
								System.out.println("Close\t= "+close);
								System.out.println("High\t= "+high);
								System.out.println("Low\t= "+low);
								System.out.println("Volume\t= "+volume);
								System.out.println("OpenInterest\t= "+openI);
							}
						
						
						} // end if
					}	
				} // end while
				System.out.println(lines+" lines imported from symbol "+symbol);
			} catch (IOException e1) {
				System.out.println("Error while reading line "+line);
				e1.printStackTrace();
			}
				
			// fire down database connection
			quotes.closeDB();
            
			// display elapsed time
            System.out.println("\nDone in "+timer.stopTimer());
			
		}
		
        
        
        public static void main(String[] args) {
            
            CsvImport csv = new CsvImport("./jars/eurusd.csv","./jars/config/imports/customEURUSD.xml","eurusd");
            
        }
				
	
}
