/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.quotes;


import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.LinkedList;

import sfljtse.data.DB;
import sfljtse.quotes.Stock;
import sfljtse.settings.Settings;

/**
 * @title		: DBQuotes       
 * @description	: This class manage db quotes, select/update/insert/alter/create etc  
 * @date		: 4-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class DBQuotes {

	// db object
    private DB db;

    // table type, cached hsqldb, change to "" for mySQL or other dbms.
    private final String TABLE_TYPE = "CACHED";
    
	
    /**
     * Constructor 1
     * Open and Init database ( load its name from settings )
     * @param boolean initdb  if true create DB structure 
     */
    public DBQuotes(boolean initdb) {

        String databaseName = Settings.getProperty("DBMS.DatabaseName");
        
        openDB(databaseName);
        
        if (initdb)
            initDB();
        
    }

    /**
     * Constructor 2
     * Open and Init database
     * @param databasename String
     * @param boolean initdb  if true create DB structure 
     */
    public DBQuotes(String databaseName,boolean initdb) {

        openDB(databaseName);
            
        if (initdb)
            initDB();
        
    }

    
    
    /**
     * Opens DB connection
     * @param databaseName String
     */
    private void openDB(String databaseName){
        try {
            db = new DB(databaseName,"sa","");
        } catch (Exception e) {
            System.out.println("Could not open database");
            System.exit(1);
        }        
    }
    
    /**
     *  Inits DB structure
     */
    private void initDB(){
        try {
            
            //  create table SYMBOL
            db.update("CREATE "+ TABLE_TYPE +" TABLE symbol ( " +
                        "id INTEGER IDENTITY, "                 +
                        "symbol VARCHAR(20),"                   +
                        "fullname VARCHAR(256) DEFAULT '-',"    +
                        "description VARCHAR(256) DEFAULT '-'," +
                        "groupID INTEGER DEFAULT '0'"           +
                      ")");
            // create table mktgroup
            db.update("CREATE "+ TABLE_TYPE +" TABLE mktgroup  ("   +
                        "id INTEGER IDENTITY,"                      +
                        "description VARCHAR(20) DEFAULT '-'"       +
                      ")");
            // insert "Not assigned" group  into mktgroup table
            db.update("INSERT INTO mktgroup (description) VALUES('not assigned')");
        
        } catch (SQLException e) {
            // do nothing if tables already created
        }
    }
    
	/**
	 * Close db connection
	 */
	public void closeDB() {
		// close DB connection
		try {
            db.shutdown();
        } catch (SQLException e) {
            System.out.println("Error occours while trying to close database!");
        }
	}	
	
    
	/**
	 * Insert Quote into database
	 * 
	 * @param symbol
	 * @param date
	 * @param time
	 * @param open
	 * @param close
	 * @param high
	 * @param low
	 * @param volume
	 * @param openInterest
	 * @return boolean
	 */
	public boolean insertQuotes(String symbol,String date,String time,String open,String close,String high,
							 String low,String volume,String openInterest) {
					
		try {
			String query = "SELECT DATE FROM "+symbol+" WHERE " +
			   				"DATE='"+date+"' AND TIME='"+time+"'";
			ResultSet r = db.query(query);
			if (!r.next()) {
				query = "INSERT INTO "+symbol+" (DATE,TIME,OPEN,CLOSE,HIGH,LOW,VOLUME,OPENINTEREST) " +
						"VALUES('"+date+"','"+time+"','"+open+"','"+close+"','"+high+"','"+low+"','"+volume+"','"+openInterest+"')";
				db.update(query);
			} else {
				query = "SELECT DATE FROM "+symbol+" WHERE " +
						"DATE='"+date+"' AND TIME='"+time+"' AND OPEN='"+open+"' AND CLOSE='"+close+"' AND " +
						"HIGH='"+high+"' AND LOW='"+low+"' AND VOLUME='"+volume+"' AND OPENINTEREST='"+openInterest+"'";
				r = db.query(query);
				if (!r.next()) {
					// update
					query = "UPDATE "+symbol+" SET OPEN='"+open+"',CLOSE='"+close+"',HIGH='"+high+"',LOW='"+low+"',VOLUME='"+volume+"',OPENINTEREST='"+openInterest+"' WHERE DATE='"+date+"' AND TIME='"+time+"'";
					db.update(query);
					System.out.println("Row updated.");
				} else {
					System.out.println("Row already up to date, skip insert.");
				}
				return true;
			}
		} catch (SQLException e) {
			System.err.println(e);
			return false;
		}
	
		return true;
	}
	
	/**
     * Insert symbol ticker into symbol table and create quote table
     * @param symbol
     * @param fullName
     * @param description
     * @param groupId
     * @return booolean
	 */ 
	public boolean insertSymbol(String symbol,String fullName,String description,String groupId) {
		
        boolean ret = false;
        
        // TODO: symbol must be a valid set of chars 
                
		try {
			String query;
			query = "SELECT id FROM symbol WHERE symbol='"+symbol+"'";
			ResultSet r = db.query(query); 
			if (!r.next()) { 
				query = "INSERT INTO symbol (symbol,fullname,description,groupID) VALUES('"+symbol+"','"+fullName+"','"+description+"',"+groupId+")";
                db.update(query);
				ret = true;
			} else {
				System.out.println("Symbol already exists.");
				ret = true;
			}
		} catch (SQLException e) {
			System.err.println(e);
			ret = false;
		}
	
        // create table for that symbol
        try {
            db.update("DROP TABLE "+symbol+" IF EXISTS");
            db.update("CREATE "+ TABLE_TYPE +" TABLE "+symbol+" ("  +
                        " DATE  integer NOT NULL,"   +
                        " TIME  integer DEFAULT '0',"   + 
                        " OPEN  double NOT NULL,"   +
                        " HIGH  double NOT NULL,"   +
                        " LOW   double NOT NULL,"   +
                        " CLOSE double NOT NULL,"   +
                        " VOLUME double DEFAULT '0',"  +
                        " OPENINTEREST double DEFAULT '0'," +
                        " PRIMARY KEY  (DATE,TIME)"             +
                      ")");
            ret = ret && true;
        } catch (SQLException e) {
            // do nothing is table already there
            ret = ret && false;
        }
        
        
        return ret;
	}
		

    /**
     * Delete symbol ticker
     * @param symbol
     * @return boolean
     */
    public boolean deleteSymbol(String symbol) {
        try {
            String query = "DELETE FROM symbol WHERE symbol='"+symbol+"'";
            db.update(query);
            db.update("DROP TABLE "+symbol+" IF EXISTS");
            return true;
        } catch (SQLException e) {
            System.out.println("Error while deleting symbol!");
            return false;
        }       
    }

    
    /**
     * Rename symbol ticker
     * @param symbol
     * @param newName
     * @return boolean
     */
    public boolean renameSymbol(String symbol,String newName) {
        
        // first rename the symbol int symbol's table
        try {
            String query = "UPDATE symbol SET symbol='"+newName+"' WHERE symbol='"+symbol+"'";
            db.update(query);
        } catch (SQLException e) {
            System.out.println("Error while updating symbol!");
            return false;
        }
        // ...then rename the symbol quote table
        try {
            db.update("ALTER TABLE "+symbol+" RENAME TO "+newName);
            return true;
        } catch (SQLException e) {
            System.out.println("Error while renaming quotes table!");
            return false;
        }
       
    }

	
    /**
     * Get symbol's fullname
     * @param symbol
     * @return
     */
    public String getSymbolFullName(String symbol) {
        
        try {
            String query = "SELECT fullName FROM symbol WHERE symbol='"+symbol+"'";
            ResultSet rs = db.query(query);
            rs.first();
            return rs.getString("fullName").trim();
        } catch (SQLException e) {
            return null;
        }
    }
    
    
    /**
     * Gets all symbols
     * @param symbol
     * @return
     */
    public LinkedList getAllSymbols() {
        
        LinkedList symbols = new LinkedList();        
        
        
        try {
            String query = "SELECT symbol,fullname,description,m.description AS market FROM symbol S,mktgroup M";
            query = query + " WHERE S.groupID=M.ID";
            ResultSet rs = db.query(query);
            while (rs.next()) {
               String[] tmp = new String[4];
               tmp[0] = rs.getString("symbol").trim();
               tmp[1] = rs.getString("fullname").trim();
               tmp[2] = rs.getString("market").trim();
               tmp[3] = rs.getString("description").trim();
               
               symbols.add(tmp);
            }
            return symbols;
        } catch (SQLException e) {
            System.out.println("Error while trying to fetchs symbols!");
            return null;
        }
    }
    
    
    
    
    /**
     * Get symbol's description
     * @param symbol
     * @return
     */
    public String getSymbolDescription(String symbol) {
        
        try {
            String query = "SELECT description FROM symbol WHERE symbol='"+symbol+"'";
            ResultSet rs = db.query(query);
            rs.first();
            return rs.getString("description").trim();
        } catch (SQLException e) {
            return null;
        }
    }
	
	
	/**
	 * Return all quotes for one symbol 
	 * @param ticker
	 * @return
	 */
	private ResultSet getAllQs(String symbol) {
		try {
			String query = "SELECT DATE,TIME,OPEN,HIGH,LOW,CLOSE,VOLUME,OPENINTEREST FROM "+symbol+" ORDER BY DATE DESC";
            return db.query(query);
		} catch (SQLException e) {
			System.out.println("ERROR:"+e);
			return null;
		}

	}
	
	
	/**
	 * Get quotes range between two date
	 * @param ticker
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	private ResultSet getRangeQs(String symbol,String startDate,String endDate) {
		try {
			String query = "SELECT DATE,TIME,OPEN,HIGH,LOW,CLOSE,VOLUME,OPENINTEREST FROM "+symbol+" WHERE "+
					"DATE BETWEEN '"+startDate+"' AND '"+endDate+"' " +
					"ORDER BY DATE DESC";
			return db.query(query);
		} catch (SQLException e) {
			System.out.println("ERROR:"+e);
			return null;
		}

	}
	
	
    /**
     * Load quotes from DB to LinkedList
     * @param Symbol
     * @return
     */
	public LinkedList getQuotes(String symbol,String startDate,String endDate) { 
    	      
    	LinkedList quotes = new LinkedList();	

    	
    	ResultSet rs;
		if (startDate==null&&endDate==null)
		   rs = getAllQs(symbol);
		else
		   rs = getRangeQs(symbol,startDate,endDate);

		try {
			while (rs.next()) {
			
				// cicla per tutte le righe
				Stock stock = new Stock();

				stock.setDate(rs.getInt("DATE"));
				stock.setTime(rs.getInt("TIME"));
				stock.setOpen(rs.getDouble("OPEN"));
				stock.setHigh(rs.getDouble("HIGH"));
				stock.setLow(rs.getDouble("LOW"));
				stock.setClose(rs.getDouble("CLOSE"));
				stock.setVolume(rs.getLong("VOLUME"));
				stock.setVolume(rs.getLong("OPENINTEREST"));

				quotes.addFirst(stock);
			}
		} catch (SQLException e) {			
			e.printStackTrace();
		}
 
    	return quotes;
    }	

	
	
}
