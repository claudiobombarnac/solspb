/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.quotes;

import java.util.LinkedList;


/**
 * @title		: LoadQuotes       
 * @description	: Loads quotes into LinkedList for fast processing  
 * @date		: 4-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class LoadQuotes {

	private boolean debug=false;
	
	/**
	 * Constructor 1 (default)
	 *
	 */
	public LoadQuotes() {	
		this.debug = false;
	}

	/**
	 * Constructor 2 (debug option)
	 * @param debug
	 */
	public LoadQuotes(boolean debug) {
		this.debug = debug;
	}
	
	/**
	 * Load All quotes into LinkedList
	 * @param ticker
	 * @return
	 */
	public LinkedList loadAllQuotes(String ticker) {
		
		// fireup database connection
		DBQuotes myDBquotes = new DBQuotes(true);		
		LinkedList quotes = myDBquotes.getQuotes(ticker,null,null);
		
		// debug info
		if (debug) {
			if (!quotes.isEmpty())
				System.out.println("Loaded in memory all "+quotes.size()+" quotes for symbol "+ticker);
			else
				System.out.println("No quotes found for symbol "+ticker);	
		}
				
		// close connection
		myDBquotes.closeDB();
		
		return quotes;
	}
	
	/**
	 * Load into memory a range of quotes defined by two dates
	 * @param ticker
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	public LinkedList loadRangeQuotes(String ticker,String startDate,String endDate) {

		// fireup database connection
		DBQuotes myDBquotes = new DBQuotes(true);
		
		LinkedList quotes = myDBquotes.getQuotes(ticker,startDate,endDate);
		
		// debug info
		if (debug) {
			if (!quotes.isEmpty())
				System.out.println("Loaded in memory "+quotes.size()+" quotes for symbol "+ticker
						+" from "+startDate+" to "+endDate);
			else
				System.out.println("No quotes found for symbol "+ticker);	
		}
				
		// close connection
		myDBquotes.closeDB();
		
		return quotes;
	}

	/**
	 * Main for test only, show Hot to use this class
	 * @param args
	 */
	public static void main(String[] args) {
		// How to load dbQuotes into a LinkedList
		LoadQuotes myQuotes = new LoadQuotes(true); // enable verbose debug output
		LinkedList mib30 = myQuotes.loadAllQuotes("mib30");
		LinkedList mib30_rg = myQuotes.loadRangeQuotes("mib30","2004-09-20","2004-09-30");

		// 	How to get data into LinkedList
		for (int i=0;i<mib30_rg.size();i++) {
			Stock stock = (Stock)mib30_rg.get(i);
			System.out.println("DATE="+stock.getDate()+" OPEN="+stock.getOpen()+" CLOSE="+stock.getClose());
		}
	}
}
