/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.quotes;

import java.util.LinkedList;

import sfljtse.quotes.Stock;


/**
 * @title		: Price       
 * @description	: Manages values on price list  
 * @date		: 4-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Price {

    private LinkedList quotes;
    
   
    /**
     * Constructor
     * @param quotes
     */
    public Price(LinkedList quotes){
        this.quotes = quotes;
    }

    /**
     * Gets the size of price list
     * @return int
     */
    public int getSize(){
       return quotes.size(); 
    }
    
    /**
     * Gets First
     * @return int
     */
    public int getFirst(){
        return quotes.indexOf(quotes.getFirst());
    }

    /**
     * Gets Last
     * @return int
     */
    public int getLast(){
        return quotes.indexOf(quotes.getLast());
    }
    
    
    /**
     * Gets DATE
     * @param i
     * @return int
     */
    public int getDate(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getDate();
    }

    /**
     * Gets TIME
     * @param i
     * @return int
     */
    public int getTime(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getTime();
    }

    /**
     * Gets OPEN
     * @param i
     * @return double
     */
    public double getOpen(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getOpen();
    }

    /**
     * Gets HIGH
     * @param i
     * @return double
     */
    public double getHigh(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getHigh();
    }

    /**
     * Gets LOW
     * @param i
     * @return double
     */
    public double getLow(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getLow();
    }

    /**
     * Gets Close
     * @param i
     * @return double
     */
    public double getClose(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getClose();
    }

    /**
     * Gets VOLUME
     * @param i
     * @return double
     */
    public long getVolume(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getVolume();
    }
    
    /**
     * Gets OPEN INTEREST
     * @param i
     * @return double
     */
    public long getOpenInterest(int i){
        Stock stock = (Stock)quotes.get(i);
        return stock.getOpenInterest();
    }
    
}
