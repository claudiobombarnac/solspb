/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.quotes;

/**
 * @title		: Stock       
 * @description	: Gets/Sets value for a single price record  
 * @date		: 4-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Stock
{
    private int		date;
    private int 	time;
    private double  open;
    private double  high;
    private double  low;
    private double  close;
    private long  	volume;
    private long    openInterest;
       
    
    // gets
    public int 		getDate() 	{ return date; 	}
    public int 		getTime() 	{ return time; 	}
    public double	getOpen() 	{ return open; 	}
    public double 	getHigh() 	{ return high; 	}
    public double 	getLow() 	{ return low; 	}
    public double 	getClose() 	{ return close; }
    public long 	getVolume() { return volume; }
    public long 	getOpenInterest() { return openInterest; }

    // sets
    public void 	setDate(int Date) 		{ date = Date; 	}
    public void 	setTime(int Time)		{ time = Time; 	}    
    public void 	setOpen(double Open) 	{ open = Open; 	}
    public void 	setHigh(double High) 	{ high = High; 	}
    public void 	setLow(double Low) 		{ low = Low; 	}
    public void 	setClose(double Close) 	{ close = Close; }
    public void 	setVolume(long Volume)	{ volume = Volume; }
    public void		setOpenInterest(long OpenInterest) { openInterest = OpenInterest; }
    
}
