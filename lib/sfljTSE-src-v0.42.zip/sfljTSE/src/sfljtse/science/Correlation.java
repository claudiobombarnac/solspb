/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.science;

/**
 * @title		: Correlation       
 * @description	: Calc Correlation  
 * {@code    
 * 
 *      Correlation corr = new Correlation();
 *      for(int i=0;i<quotes;i++)
 *          corr.add(yield1,yield2);
 *      System.out.println("Correlation between yield1 and yield2 is "+corr.getCorrelation());
 *  }  
 * @date		: 19-set-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Correlation {
        
        private long n      = 0;         // number of values
        private double x    = 0.0;       // sum of X
        private double y    = 0.0;       // sum of Y
        private double x2   = 0.0;      // sum of X^2
        private double y2   = 0.0;      // sum of Y^2
        private double xy   = 0.0;      // sum of X*Y

        /**
         * Constructor
         */
        public Correlation() {
        }

        /**
         * Add values
         * @param a
         * @param b
         */
        public void add(double a, double b) {
            n++;
            x += a;
            y += b;
            x2 += a * a;
            y2 += b * b;
            xy += a * b;
        }
        
        /**
         * gets counts
         * @return
         */
        public long getCount() {
            return n;
        }
        
        /**
         * gets correlation
         */
        public double getCorrelation() {
            if (n < 2)
                throw new ArithmeticException();
            
            double d0 = (double)n * xy - x * y;
            double d1 = Math.sqrt((double)n * x2 - x * x);
            double d2 = Math.sqrt((double)n * y2 - y * y);
            return d0 / (d1 * d2);
        }
        
        /**
         * Gets A, stands for y = Ax + B
         */
        public double getA() {
            if (n < 2)
                throw new ArithmeticException();
            return ((double)n * xy - x * y)/((double)n * x2 - x * x);
        }

        /**
         * Gets B, stands for y = Ax + B
         */
        public double getb(){
            if (n < 2)
                throw new ArithmeticException();
            return y / (double)n - x / (double)n * getA();
        }
}
