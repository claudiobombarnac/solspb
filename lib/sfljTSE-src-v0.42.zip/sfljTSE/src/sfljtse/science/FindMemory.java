/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.science;

import java.util.LinkedList;

import sfljtse.utils.Common;

/**
 * @title		: FindMemory       
 * @description	: Finds if memory could be present by given predictors
 * @date		: 22-set-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class FindMemory {

    private int days = 0;
    private LinkedList<Double> corr     = new LinkedList<Double>();
    private LinkedList<String> predict  = new LinkedList<String>();
    
    /**
     * Constructor
     * @param days
     */
    public FindMemory(int days){
        this.days = days;
    }
    
    /**
     * Add correletion's value
     * @param Double value
     * @param String label
     */
    public void add(Double value,String label){
        corr.add(value);
        predict.add(label);
    }

    /**
     * Add correletion's value ( Overrides previus methos )
     * @param Double value
     */
    public void add(Double value){
        corr.add(value);
        predict.add("");
    }

    
    /**
     * Prints on stdout predictor, its correlation and result of bartlett test 95%
     */
    public void printMemoryTest(){
      
        System.out.println("[Memory Test]");
        System.out.println("----------------------------------------------------------");

        Bartlett bart = new Bartlett(days);
        double b  = bart.getValue();
        
        System.out.println("Bertlett Test 95% : "+Common.round(b,4));
        
        for (int i=0;i<corr.size();i++){
            String tmpPredict = "Predictor";
            double c     = corr.get(i);
            String label = predict.get(i);

            if (label.trim().equalsIgnoreCase(""))
                tmpPredict = tmpPredict + " " + i;
            else
                tmpPredict = label;
            if (testBartlett95(c))
                System.out.println( tmpPredict + " : " + Common.round(c,4) + " [PASSED, could be memory]");
            else
                System.out.println( tmpPredict + " : " + Common.round(c,4) + " [FAILED, could be random]");
        } // end for        
        
        System.out.println("----------------------------------------------------------");
    }
    
    /**
     * Returns true if Bartlett Test 95 is passed
     * @param double c
     * @return boolean
     */
    public boolean testBartlett95(double c){
        Bartlett bart = new Bartlett(days);
        double b  = bart.getValue();
        if (Math.abs(c)>b)
            return true;
        else
            return false;
    }
    
}// end class
