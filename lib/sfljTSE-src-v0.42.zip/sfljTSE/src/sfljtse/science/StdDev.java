/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.science;

/**
 * @title		: StdDev       
 * @description	: Calc Standard Deviation
 * @date		: 19-set-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class StdDev {
        
        private long n      = 0;
        private double x    = 0.0;
        private double x2   = 0.0;

        /**
         * Constructor
         */
        public StdDev(){
        }

        /**
         *  add a number to the pool
         */  
        public void add(double d){
            n++;
            x += d;
            x2 += d * d;
        }

        /**
         * Gets count
         */
        public long getCount(){
            return n;
        }

        /**
         * Gets Mean
         */
        public double getMean() {
            if (n < 1)
                throw new ArithmeticException();
            return x / (double)n;
        }

        /**
         * Gets Standard Deviation
         * @return
         */
        public double getStdDev() {
            if (n < 2)
                return 0;
            double d1 = (double)n * x2 - x * x;
            double d2 = (double)n * (double)(n - 1);
            return Math.sqrt(d1/d2);
        }
        
} // end class
