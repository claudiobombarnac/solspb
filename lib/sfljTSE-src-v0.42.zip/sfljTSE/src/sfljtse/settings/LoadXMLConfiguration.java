/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.settings;

import java.io.File;
import java.util.Date;

import sfljtse.alarms.Alarm;
import sfljtse.alarms.Execute;
import sfljtse.alarms.model.IAlarm;
import sfljtse.quotes.LoadQuotes;
import sfljtse.quotes.Price;
import sfljtse.stats.Equity;
import sfljtse.trader.Account;
import sfljtse.trader.Commission;
import sfljtse.stats.Report;
import sfljtse.trader.Signal;
import sfljtse.utils.Common;
import sfljtse.xml.ReadXML;

/**
 * @title		: LoadXMLConfiguration       
 * @description	:  
 * @date		: 26-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class LoadXMLConfiguration {

    private String xmlFile;
    private ReadXML xml;
    private boolean verbose = false;
    
    /**
     * Constructor
     * @param xmlFile
     */
    public LoadXMLConfiguration(String xmlFile,boolean verbose){
        this.xmlFile = xmlFile;
        this.verbose = verbose;
        File f = new File(xmlFile);
        if (f.exists()){
            xml = new ReadXML(xmlFile);    
        } else {
            System.out.println("Cannot find file "+xmlFile+", please check it out and try again!");
            System.exit(1);
        }       
    }
    
    /**
     * Gets symbols
     * @return
     */
    public String[] getSymbols(){
        return xml.getValuesOf(XML.tag_SYMBOLS,XML.tag_SYMBOLS_SYMBOL);
    }
    
    /**
     * Gets prices
     * @param symbol String
     * @return Price 
     */
    public Price getPrices(String symbol){
        if (verbose) System.out.println("Loading quotes...");
        /*
         *  Creates a quotes object and loads prices
         */
        LoadQuotes myQuotes = new LoadQuotes(false);
        
        // check if there a period tag
        String periods = xml.getValueOf(XML.tag_QUOTES,XML.tag_QUOTES_PERIODS);
        // check if periods = ALL and loads all quotes from symbol
        if (periods.trim().equalsIgnoreCase(XML.type_ALL)) {
            return new Price(myQuotes.loadAllQuotes(symbol));
        }
        
        // if no period tag, there are from and to tags
        if (periods.trim().equalsIgnoreCase("")){
            String from = xml.getValueOf(XML.tag_QUOTES,XML.tag_QUOTES_FROM);
            String to   = xml.getValueOf(XML.tag_QUOTES,XML.tag_QUOTES_TO);
            if (from.trim().equalsIgnoreCase("")||to.trim().equalsIgnoreCase("")){
                System.out.println("Cannot loads quotes, check your configuration file "+xmlFile);
                System.exit(1);
            }            
            return new Price(myQuotes.loadRangeQuotes(symbol,Common.dateToIso(from.trim()) ,Common.dateToIso(to.trim())));    
        }
        return null;       
    }
    
    /**
     * gets Account settings
     * @return
     */
    public Account getAccount(){  
        double cash = 0;
        if (verbose) System.out.println("Loading account...");
        /**
         * Check if exists an include file
         */
        String include = xml.getValueOf(XML.tag_ACCOUNT,XML.tag_INCLUDE);
        if (include.trim().equalsIgnoreCase("")){
            // include does not exists
            String name     = xml.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_NAME);
            String bank     = xml.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_BANK);
            String cc       = xml.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_CC);
            try {
                cash     = Double.valueOf(xml.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_CASH));
            }catch(Exception e){}
            String valute   = xml.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_VALUTE);
            return new Account(name,bank,cc,cash,valute);
        } else {
            // include exists
            ReadXML acc = new ReadXML(include.trim());
            String name     = acc.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_NAME);
            String bank     = acc.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_BANK);
            String cc       = acc.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_CC);
            try{
                cash     = Double.parseDouble(acc.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_CASH));
            }catch (Exception e){}
            String valute   = acc.getValueOf(XML.tag_ACCOUNT,XML.tag_ACCOUNT_VALUTE);
            return new Account(name,bank,cc,cash,valute);            
        }
    }
    
    
    /**
     * gets Account settings
     * @return
     */
    public double getTradeAccountAmount(Account account){  
        int amount = 0;
        if (verbose) System.out.println("Loading account...");
        /**
         * Check if exists an include file
         */
        String include = xml.getValueOf(XML.tag_ACCOUNT,XML.tag_INCLUDE);
        if (include.trim().equalsIgnoreCase("")){
            // include does not exists
            String type     = xml.getValueOf(XML.tag_TRADINGACCOUNT,XML.tag_TRADINGACCOUNT_TYPE).trim();
            try {
                amount   = Integer.parseInt(xml.getValueOf(XML.tag_TRADINGACCOUNT,XML.tag_TRADINGACCOUNT_AMOUNT));
            }catch(Exception e){};
            if (type.equalsIgnoreCase(XML.type_PERCENTAGE)){
                return account.getCashPercent(amount);
            }
            if (type.equalsIgnoreCase(XML.type_ALL)){
                return account.getCash();
            }
            if (type.equalsIgnoreCase(XML.type_FIXED)){
                if (amount<=account.getCash())
                    return amount;
                else {
                    // return all cash avaible even if you requested 
                    // more then those avaible on you bank account
                    System.out.println("Trading account cannot be larger then bank account!");
                    return account.getCash();
                }
            }            
        } else {
            // include exists
            ReadXML acc = new ReadXML(include.trim());
            String type     = acc.getValueOf(XML.tag_TRADINGACCOUNT,XML.tag_TRADINGACCOUNT_TYPE).trim();            
            try{
                amount   = Integer.parseInt(acc.getValueOf(XML.tag_TRADINGACCOUNT,XML.tag_TRADINGACCOUNT_AMOUNT));
            }catch(Exception e){};
            if (type.equalsIgnoreCase(XML.type_PERCENTAGE)){
                return account.getCashPercent(amount);
            }
            if (type.equalsIgnoreCase(XML.type_ALL)){
                return account.getCash();
            }
            if (type.equalsIgnoreCase(XML.type_FIXED)){
                if (amount<=account.getCash())
                    return amount;
                else {
                    // return all cash avaible even if you requested 
                    // more then those avaible on you bank account
                    System.out.println("Trading account cannot be larger then bank account!");
                    return account.getCash();
                }
            }            

            return 0;            
        }
        return 0;
    }

    
    /**
     * gets commission settings
     * @return
     */
    public Commission getCommissions(){
        double base = 0;
        double percentage = 0;
        double upto = 0;
        double slippage = 0;
        
        if (verbose) System.out.println("Loading commissions...");
        /**
         * Check if exists an include file
         */
        String include = xml.getValueOf(XML.tag_COMMISSIONS,XML.tag_INCLUDE);
        if (include.trim().equalsIgnoreCase("")){
            // no include, load from this xml
            try {
                base         = Double.parseDouble(xml.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_BASE));
                percentage   = Double.parseDouble(xml.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_PERCENTAGE));
                upto         = Double.parseDouble(xml.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_UPTO));
                slippage     = Double.parseDouble(xml.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_SLIPPAGE));
            }catch(Exception e){}
            return new Commission(base,percentage,upto,slippage);
        } else {
            // include file found, load that file
            ReadXML comm = new ReadXML(include.trim());
            try {
                base         = Double.parseDouble(comm.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_BASE));
                percentage   = Double.parseDouble(comm.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_PERCENTAGE));
                upto         = Double.parseDouble(comm.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_UPTO));
                slippage     = Double.parseDouble(comm.getValueOf(XML.tag_COMMISSIONS,XML.tag_COMMISSIONS_SLIPPAGE));
            }catch(Exception e){}
            return new Commission(base,percentage,upto,slippage);
        }
    }
    
    /**
     * gets Reports from system
     * @param signal
     * @param equity
     * @param systemName
     */
    public void getReports(Signal signal,Equity equity,String systemName){
        String statistics = "no";
        String tradelist  = "no";
        String _equity    = "no";
        String format     = "no";
        String repo       = "";
        String fileName   = "";
        
        // create report object
        Report systemReport = new Report(systemName,signal,equity); 
        // read XML 
        statistics   = xml.getValueOf(XML.tag_REPORTS,XML.tag_REPORTS_STATISTICS);
        tradelist    = xml.getValueOf(XML.tag_REPORTS,XML.tag_REPORTS_TRADELIST);
        _equity      = xml.getValueOf(XML.tag_REPORTS,XML.tag_REPORTS_EQUITY);
        format       = xml.getValueOf(XML.tag_REPORTS,XML.tag_REPORTS_FORMAT);
        repo         = xml.getValueOf(XML.tag_REPORTS,XML.tag_REPORTS_REPOSITY);        
        
        // is HTML requested? ignore yes/no and produce a full HTML report
        if (format.equalsIgnoreCase(XML.type_HTML)){

            String systemReportRepo  = repo + systemName + "-" + (new Date()).toString().replaceAll(" ","_").replaceAll(":","");
            systemReport.generateHTMLReport(systemReportRepo);
            
            /*
            if (statistics.equalsIgnoreCase(XML.type_YES)){
                fileName = repo + systemName + "-Statistics-" + (new Date()).toString().replaceAll(" ","_").replaceAll(":","") + ".html";
                systemReport.generateHTMLStatistics(fileName);
            }
            if (tradelist.equalsIgnoreCase(XML.type_YES)){
                fileName = repo + systemName + "-TradeList-" + (new Date()).toString().replaceAll(" ","_").replaceAll(":","") + ".html";
                systemReport.generateHTMLTradeList(fileName);
            }
            if (_equity.equalsIgnoreCase(XML.type_YES)){
                fileName = repo + systemName + "-Equity-" + (new Date()).toString().replaceAll(" ","_").replaceAll(":","") + ".png";
                systemReport.generateEquity(fileName);  
            } 
            */    
        } 

        // is STDOUT requested?
        if (format.equalsIgnoreCase(XML.type_STDOUT)){
            if (statistics.equalsIgnoreCase(XML.type_YES))
                systemReport.generateStatistics();
            if (tradelist.equalsIgnoreCase(XML.type_YES))
                systemReport.generateTradeList();
            if (_equity.equalsIgnoreCase(XML.type_YES)){
                fileName = repo + systemName + "-Equity-" + (new Date()).toString().replaceAll(" ","_") + ".png";
                systemReport.generateEquity(fileName);  
            }     
        } 
                
    }
    
    // TODO
    public Alarm getAlarms(){
        IAlarm alarm = null;
        String type = xml.getValueOf(XML.tag_ALARMS,XML.tag_ALARMS_TYPE).trim();
        
        if (type.equalsIgnoreCase(XML.alarm_EXECUTE)){
            alarm = new Execute();
        }
        
        return (Alarm) alarm;
    } 
    
}
