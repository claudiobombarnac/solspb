/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.settings;

import java.io.File;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.util.Properties;

/**
 * @title		: Settings       
 * @description	: Saves/loads properties from a properties file  
 * @date		: 4-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Settings {
	
    /** holds the properties */
	private static Properties _properties;
 	
    private static String fileName = "sfljTSE.properties";
    
 	/** loads the properties at start */
	static {
		load(fileName);
	}
	
	/** 
	 *	Loads the properties-file
	 *  @param file the filename
	 */
	public static void load(String file) {
        try {
        	_properties = new Properties();
            _properties.setProperty("DBMS.DatabaseName", "./data/default");
            _properties.setProperty("WorkingDir", "./");

            BufferedInputStream buffer = new BufferedInputStream(new FileInputStream(new File(file)));
        	_properties.load(buffer);
        } catch (Exception e) {
        	save(fileName);
            System.out.println("Error while loading properties, using defaults");
        }
	}
	
	/** 
	 *	Saves the properties-file
	 *  @param file the filename
	 */
	public static void save(String file) {
        try {
        	BufferedOutputStream buffer = new BufferedOutputStream(new FileOutputStream(new File(file)));
        	_properties.store(buffer, null);
        } catch (Exception e) {
        	System.out.println("Error while saving properties");
        }
	}
	
	/** 
	 *	get a property
	 *  @param name of the key
	 *  @return value
	 */
	public static String getProperty(String name) {
		return _properties.getProperty(name);
	}	

	
	/** 
	 *	set a property
	 *  @param name of the key
	 *  @param value the new value
	 */
	public static void setProperty(String name, String value) {
		_properties.setProperty(name, value);
	}
}