/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.settings;

/**
 * @title		: XML       
 * @description	: Defines XML structure 
 * @date		: 26-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class XML {

    /**
     * Usefull XML value constants
     */
    public static final String type_PERCENTAGE          = "PERCENTAGE";
    public static final String type_FIXED               = "FIXED";
    public static final String type_ALL                 = "ALL";
    public static final String type_YES                 = "YES";
    public static final String type_NO                  = "NO";
    public static final String tag_INCLUDE              = "INCLUDE";
    public static final String type_HTML                = "HTML";
    public static final String type_TEXT                = "TEXT";
    public static final String type_STDOUT              = "STDOUT";
    public static final String type_FORMAT_CVS          = "CVS";
    public static final String type_FORMAT_METASTOCK    = "MS";
    public static final String type_INTRADAY            = "DAILY";
    public static final String type_DAILY               = "DAILY";
    public static final String type_WEEKLY              = "WEEKLY";
    public static final String type_DDmonthYYYY         = "dd-month-yyyy";
    public static final String type_DDMMYYYY            = "ddmmyyyy";
    public static final String type_MMDDYYYY            = "mmddyyyy";
    
    /**
     * Alarm types
     */
    public static final String alarm_EMAIL              = "EMAIL";
    public static final String alarm_SMS                = "SMS";
    public static final String alarm_WIN                = "WINDOW";
    public static final String alarm_SOUND              = "SOUND";
    public static final String alarm_EXECUTE            = "EXECUTE";
    
    
    
    /**
     * Quotes strings
     */
    public static final String quote_DATE       = "DATE";
    public static final String quote_TIME       = "TIME";
    public static final String quote_HIGH       = "HIGH";
    public static final String quote_LOW        = "LOW";
    public static final String quote_OPEN       = "OPEN";
    public static final String quote_CLOSE      = "CLOSE";
    public static final String quote_VOLUME     = "VOLUME";
    public static final String quote_ADJVOLUME  = "ADJVOLUME";
    public static final String quote_OPENINT    = "OPENINT";
    public static final String quote_SKIP       = "SKIP";
    
    
    /**
     * Account Tags
     */
    public static final String tag_ACCOUNT              = "ACCOUNT";
    public static final String tag_ACCOUNT_INCLUDE      = "INCLUDE";
    public static final String tag_ACCOUNT_NAME         = "NAME";
    public static final String tag_ACCOUNT_BANK         = "BANK";
    public static final String tag_ACCOUNT_CC           = "CC";
    public static final String tag_ACCOUNT_CASH         = "CASH";
    public static final String tag_ACCOUNT_VALUTE       = "VALUTE";
    
    
    /**
     * Alarms tags
     */
    public static final String tag_ALARMS           = "ALARMS";
    public static final String tag_ALARMS_TYPE      = "TYPE";
    public static final String tag_ALARMS_EMAIL     = "EMAIL";
    public static final String tag_ALARMS_TEXT      = "TEXT";
    public static final String tag_ALARMS_GSMNUMBA  = "GSM_NUMBA";
    public static final String tag_ALARMS_COMMAND   = "COMMAND";
    public static final String tag_ALARMS_FILE      = "FILE";
    
    /**
     * TradingAccount tags
     */
    public static final String tag_TRADINGACCOUNT           = "TRADING_ACCOUNT";
    public static final String tag_TRADINGACCOUNT_TYPE      = "TYPE";
    public static final String tag_TRADINGACCOUNT_AMOUNT    = "AMOUNT";
   
    /**
     * Investement Strategy
     */
    public static final String tag_INVEST           = "INVEST_STRATEGY";
    public static final String tag_INVEST_TYPE      = "INVEST_TYPE";
    public static final String tag_INVEST_AMOUNT    = "INVEST_AMOUNT";
        
    /**
     * Commission tags
     */
    public static final String tag_COMMISSIONS              = "COMMISSIONS";
    public static final String tag_COMMISSIONS_BASE         = "BASE";
    public static final String tag_COMMISSIONS_PERCENTAGE   = "PERCENTAGE";
    public static final String tag_COMMISSIONS_UPTO         = "UPTO";
    public static final String tag_COMMISSIONS_SLIPPAGE     = "SLIPPAGE";

    /**
     * Symbols tags
     */
    public static final String tag_SYMBOLS          = "SYMBOLS";
    public static final String tag_SYMBOLS_SYMBOL   = "SYMBOL";
    
    /**
     * Systems tags
     */
    public static final String tag_SYSTEMS          = "SYSTEMS";
    public static final String tag_SYSTEMS_SYSTEM   = "SYSTEM";
    
    /**
     * Quotes tags
     */
    public static final String tag_QUOTES           = "QUOTES";
    public static final String tag_QUOTES_FROM      = "FROM";
    public static final String tag_QUOTES_TO        = "TO";
    public static final String tag_QUOTES_PERIODS   = "PERIODS";
    
    /**
     * Reports tags
     */
    public static final String tag_REPORTS              = "REPORTS";
    public static final String tag_REPORTS_STATISTICS   = "STATISTICS";
    public static final String tag_REPORTS_TRADELIST    = "TRADELIST";
    public static final String tag_REPORTS_EQUITY       = "EQUITY";
    public static final String tag_REPORTS_FORMAT       = "FORMAT";
    public static final String tag_REPORTS_REPOSITY     = "REPOSITY";
    
    /**
     * Provider tags
     */
    public static final String tag_PROVIDER         = "PROVIDER";
    public static final String tag_PROVIDER_NAME    = "NAME";
    public static final String tag_PROVIDER_URL     = "URL";
    
    /**
     * Format tags
     */
    public static final String tag_FORMAT               = "FORMAT";
    public static final String tag_FORMAT_TYPE          = "TYPE";
    public static final String tag_FORMAT_SEPARATOR     = "SEPARATOR";
    public static final String tag_FORMAT_TEXTDELIMITER = "TEXT_DELIMITER";
    public static final String tag_FORMAT_DATEFORMAT    = "DATE_FORMAT"; 
    public static final String tag_FORMAT_TIMEFORMAT    = "TIME_FORMAT";

    /**
     * Field tags
     */
    public static final String tag_FIELDS       = "FIELDS";
    public static final String tag_FIELDS_FIELD = "FIELD";
    
    
}
