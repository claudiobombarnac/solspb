/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.stats;

import java.util.LinkedList;

import sfljtse.utils.Common;

/**
 * @title		: Equity       
 * @description	: Simple equity line 
 * @date		: Jul 9, 2005   
 * @update      : Jul 15, 2005
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Equity {


    private LinkedList<Double> total = new LinkedList<Double>();
    
    /**
     * Constructor 
     * @param initialEquity double
     */
    public Equity(double initialEquity){
        // init first value
        total.clear();
        total.add(initialEquity);
    }
    
    
    /**
     * Return initial equity
     * @return double
     */
    public double getInitialEquity(){
        return total.getFirst();
    }
    
    /**
     * Returns final equity
     * @return doubl
     */
    public double getFinalEquity(){
        return Common.round(total.get(total.size()-1),2);
    }
    
    
    /**
     * Set Equity value
     * @param equityValue double
     */
    public void setEquity(double equityValue){
        total.addLast(total.getLast() + equityValue);
    }
    
    /**
     * Returns equity value for a given i
     * @param i int
     * @return double 
     */
    public double getEquity(int i){
        return Common.round(total.get(i),2);
    }
    
       
}
