/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.stats;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;

import sfljtse.science.StdDev;
import sfljtse.stats.Equity;
import sfljtse.stats.Stats;
import sfljtse.stats.Trade;
import sfljtse.trader.PositionType;
import sfljtse.trader.Signal;
import sfljtse.trader.TradeAccount;
import sfljtse.utils.Common;
import sfljtse.utils.Writer;

/**
 * @title		: Report       
 * @description	:  
 * @date		: 14-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Report {

    private LinkedList trades;
    private LinkedList openTrades;
    
    private Stats stat = new Stats();
    
    private Equity equity;
    private TradeAccount tAccount;
    private String systemName = "";
    
    /**
     * Constructor
     * @param signals
     */
    public Report(String systemName,Signal signals,Equity equity){
        this.trades     = signals.tradeList.getFullTradeList();
        this.openTrades = signals.portfolio.getPortfolioEntries();
        this.equity = equity;
        this.tAccount = signals.tAccount;
        this.systemName = systemName;
        // does dirty work!
        calcStatistics();
    }

    /**
     * Generate HTML reports
     * @param systemReportRepo
     * @return
     */
    public void generateHTMLReport(String systemReportRepo){
        // create directory Reposity
        boolean success = (new File(systemReportRepo)).mkdir();
        if (!success) {
            System.out.println("Cannot create directory ["+systemReportRepo+"], please check your permissions and try again!");
            return;
        } // else... if everything goes fine...

        
        String index            = systemReportRepo+"/index.html";
        String statFileName     = systemReportRepo+"/statistics.html";
        String tradesFileName   = systemReportRepo+"/tradelist.html";
        String equityFileName   = systemReportRepo+"/equity.png";
        
        // generate statistics
        this.generateHTMLStatistics(statFileName);
        // generate tradelist
        this.generateHTMLTradeList(tradesFileName);
        // generate equity's image
        this.generateEquity(equityFileName);
        // generate systemsettings ( index.html ) 
        this.generateHTMLIndex(index,statFileName,tradesFileName,equityFileName);
    }
    
    /**
     * Generate HTML index page, referring to others webpages for statistics, tradelist and equity
     * @param index
     * @param statFileName
     * @param tradesFileName
     * @param equityFileName
     */
    private void generateHTMLIndex(String index,String statFileName,String tradesFileName,String equityFileName){
        Writer htm = null;
        try {
                htm = new Writer(index);
        } catch (IOException e) {
            System.out.println("Cannot write file "+index);
            System.exit(1);
        }
        htm.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        htm.write("<HTML lang=\"en\">");
        htm.write("<head>");
        htm.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">");
        htm.write("<title>System's report</title>");
        htm.write("</head>");        
        htm.write("<BODY>");
        htm.write("<STYLE>");
        htm.write("body  {background-color: white;font-family: sans-serif;font-size: small;color: darkblue;}");
        htm.write("table {background-color: gray;font-size: 12px;color: black;}");
        htm.write("h1 {font-size: huge;letter-spacing:4;font-weight: bold;color: gray;}");
        htm.write("p {font-size: small;letter-spacing:2;font-weight: bold;color: gray;}");
        htm.write("p.copy {font-size: 10;letter-spacing:2;color: gray;}");
        htm.write("</STYLE>");
        
        htm.write("<H1>"+systemName.trim()+" System Report</H1>");
        htm.write("<HR color=\"#D2DFFF\" size=\"35px\">");
        htm.write("<p><a href=\"statistics.html\">Statistics</a></p>");
        htm.write("<p><a href=\"tradelist.html\">Trades List</a></p>");
        htm.write("<p><a href=\"equity.png\">Equity Line</a></p>");
        htm.write("<HR color=\"#D2DFFF\" size=\"15px\">");        
        // close HTML file
        htm.write("<BR>");
        htm.write("<p class=\"copy\">&copy <a href=\"http://www.sourceforge.net/projects/sfljtse\" alt=\"\"><b>sfljTSE</b></a> opensource</p>");
        htm.write("</BODY>");
        htm.write("</HTML>");
        try {
            htm.close();
        } catch (IOException e) {
            System.out.println("Cannot close file "+index);
        }  
    }
    
   
    /**
     * Calculates statistical data
     */
    private void calcStatistics(){ 
           
        double stdDev               = 0;
        double singleNetPercent     = 0;
        double singleGrossProfit    = 0;
        double singleNetProfit      = 0;
        double singleNetPercentCum  = 0;
        double maxEquity            = 0;
        double equityl              = 0;
        double dd                   = 0;
        double maxDD                = 0;
        int    consecutiveWin       = 0;
        int    consecutiveLos       = 0;
        int    maxConsecutiveWin    = 0;
        int    maxConsecutiveLos    = 0;
        double maxWinner            = 0;
        double maxLoser             = 0;
        
        // Sets Buy and Hold
        try {
            Trade tmpB = (Trade) trades.get(0);
            Trade tmpH = (Trade) trades.get(trades.size()-1);
            double bhProfit = (tmpH.getEndPrice()*tmpH.getEndQty()) - (tmpB.getStartPrice()*tmpB.getStartQty());
            double commSlip = tAccount.calcCommission(tmpB.getStartPrice()*tmpB.getStartQty()) + tAccount.calcCommission(tmpH.getEndPrice()*tmpH.getEndQty()) + tAccount.calcSlipPage()*2; 
            double bhNetProfit = bhProfit - commSlip;
            stat.setBHProfit(bhNetProfit);
        }catch (Exception e){
            stat.setBHProfit(0);
        }
        // ---
        
        StdDev stddev = new StdDev();
        
        for (int i=0;i<trades.size();i++){
            Trade trade = (Trade) trades.get(i);
    
            /**
             * Is a Long or Short trade?
             */
            if (trade.getPositionType().get()==PositionType.LONG){
                // IS LONG
                stat.incLongTrades();
                // Is a winner?
                double grossGain = (trade.getEndPrice()*trade.getEndQty())-(trade.getStartPrice()*trade.getStartQty());
                // calc commission and slippage
                double slipStartComm = tAccount.calcCommission(trade.getStartQty()*trade.getStartPrice());
                double slipEndComm = tAccount.calcCommission(trade.getEndQty()*trade.getEndPrice());
                double slipComm = slipStartComm + slipEndComm;
                whatIs(grossGain,slipComm,true);
                singleGrossProfit = (-1)*((trade.getStartPrice()*trade.getStartQty())-(trade.getEndPrice()*trade.getEndQty()));
                singleNetProfit   = singleGrossProfit - (slipStartComm + slipEndComm); 
            }
            else {
                // IS SHORT
                stat.incShortTrades();
                double grossGain = (trade.getStartPrice()*trade.getStartQty())-(trade.getEndPrice()*trade.getEndQty());
                double slipStartComm = tAccount.calcCommission(trade.getStartQty()*trade.getStartPrice());
                double slipEndComm = tAccount.calcCommission(trade.getEndQty()*trade.getEndPrice());
                double slipComm = slipStartComm + slipEndComm;
                whatIs(grossGain,slipComm,false);
                singleGrossProfit = ((trade.getStartPrice()*trade.getStartQty())-(trade.getEndPrice()*trade.getEndQty()));
                singleNetProfit   = singleGrossProfit - (slipStartComm + slipEndComm);
            }
            
            //--------------------------
            
            singleNetPercent = stat.getPercent(singleNetProfit,(trade.getStartPrice()*trade.getStartQty()));
            singleNetPercentCum += singleNetPercent;
            
            // calc DD
            equityl += singleNetProfit;
            maxEquity = Math.max(equityl,maxEquity);
            dd = equityl - maxEquity;
            maxDD = Math.max(Math.abs(dd),Math.abs(maxDD));
            
            // inc max consecutive wins/loses
            if (singleNetProfit>0){
                consecutiveWin++;
                consecutiveLos = 0;
                maxWinner = Math.max(singleNetProfit,maxWinner);
            }
            else{
                consecutiveLos++;
                consecutiveWin = 0;
                maxLoser  = Math.min(singleNetProfit,maxLoser);
            }
            maxConsecutiveWin = Math.max(consecutiveWin,maxConsecutiveWin);
            maxConsecutiveLos = Math.max(consecutiveLos,maxConsecutiveLos);
            
            // calc stddev
            stddev.add(singleNetProfit);
            //------------------------
            
            
        } // end for

                
        // set dd
        stat.setDrawDown(maxDD);
        // set max consecutive win/los
        stat.setMaxConsecutiveWinner(maxConsecutiveWin);
        stat.setMaxConsecutiveLoser(maxConsecutiveLos);
        // set max loser/winner
        stat.setMaxWinner(maxWinner);
        stat.setMaxLoser(maxLoser);
        
        stat.setInitialCapital(equity.getInitialEquity());
        stat.setEndingCapital(equity.getFinalEquity());
        stat.setSumNetProfitPercent(singleNetPercentCum);
        
        // Calc Standard Deviation 
        stat.setStdDev(stddev.getStdDev());
                
        // calc sharpe ratio        
        double sharpe = (stat.getInitialCapital()+stat.getGrossProfit())/(double) (stat.getInitialCapital());
        stat.setSharpeRatio(sharpe);        
    }    
    
   /**
    * Is it a winner or a looser trade?
    * @param gain
    */
   private void whatIs(double grossGain,double slipComm,boolean longSide){
       double netGain = 0;
       netGain = grossGain - slipComm;
       if (netGain>=0){
           // yes it is a Winner
           stat.incWinTrades();
           stat.updateGrossProfit(grossGain);
           stat.updateNetProfit(netGain);
           stat.updateNetWinAmount(netGain);
           stat.updateGrossWinAmount(grossGain);
           equity.setEquity(netGain);
           if (longSide) 
               stat.incWinLongTrades();
           else 
               stat.incWinShortTrades();
       } else {
           // no it isn't, is a Looser!
           stat.incLossTrades();
           stat.updateGrossProfit(grossGain);
           stat.updateNetProfit(netGain);
           stat.updateGrossLossAmount(grossGain);
           stat.updateNetLossAmount(netGain);
           equity.setEquity(netGain);
       }
   }
    
    /**
     * Show statistics on standard output 
     */
   public void generateStatistics(){
        //  writes statistics on standard output
        System.out.println("[Statistics]");
        System.out.println("-----------------------------------------------------");
        System.out.println("Initial Capital : "+stat.getInitialCapital());
        System.out.println("Ending  Capital : "+stat.getEndingCapital());
        System.out.println("Gross Profit    : "+stat.getGrossProfit()+" ("+stat.getGrossSystemProfitPercent()+"%)"+ "  Tot Comm&Slipp : "+(stat.getGrossProfit()-stat.getNetProfit())+" ("+stat.getPercent((stat.getGrossProfit()-stat.getNetProfit()),stat.getGrossProfit())+"%)");
        System.out.println("Net Profit      : "+stat.getNetProfit()+" ("+stat.getNetSystemProfitPercent()+"%)");
        System.out.println("Net win amount  : "+stat.getNetWinAmount());
        System.out.println("Net loss amount : "+stat.getNetLossAmount());
        System.out.println("B&H (net)       : "+stat.getBHProfit()+" ("+stat.getPercent(stat.getBHProfit(),stat.getInitialCapital())+"%)");
        System.out.println("-----------------------------------------------------");
        System.out.println("Total Trades    : "+stat.getTradesCount());
        System.out.println(" ->Wins         : "+stat.getWinTrades()+" ("+stat.getWinPercent()+"%)"+ " Consecutive : "+stat.getMaxConsecutiveWinner()+ "  Max : "+stat.getMaxWinner()+ " ("+stat.getPercent(stat.getMaxWinner(),stat.getInitialCapital())+"%)");
        System.out.println(" ->Losses       : "+stat.getLossTrades()+" ("+stat.getLossPercent()+"%)"+ " Consecutive : "+stat.getMaxConsecutiveLosers()+ "  Max : "+stat.getMaxLoser()+ " ("+stat.getPercent(stat.getMaxLoser(),stat.getInitialCapital())+"%)");
        
        System.out.println("Long  Trades    : "+stat.getLongTrades()+"              "+"Short Trades     : "+stat.getShortTrades());
        System.out.println(" -> Win         : "+stat.getWinLongTrades()+" ("+stat.getWinLongPercent()+"%)"+"      "+" -> Win         : "+stat.getWinShortTrades()+" ("+stat.getWinShortPercent()+"%)");
        System.out.println(" -> Loss        : "+stat.getLossLongTrades()+" ("+stat.getLossLongPercent()+"%)"+"      "+" -> Loss        : "+stat.getLossShortTrades()+" ("+stat.getLossShortPercent()+"%)");
        
        System.out.println("-----------------------------------------------------");
        System.out.println("System DrawDown : "+stat.getDrawDown()+"    ("+stat.getDrawDownPercent()+"%)");
        System.out.println("Profit Factor   : "+stat.getProfitFactor());
        System.out.println("Average Profit  : "+stat.getAverageProfitMean());
        System.out.println("Average Profit% : "+stat.getAverageProfitPercent()+"%");
        System.out.println("Std Deviation   : "+stat.getStdDev());
        
        String tmpStr = "";
        if (stat.getSharpeRatio()>=2)
            if (stat.getSharpeRatio()<3)
                tmpStr = "[GOOD]";
            else
                tmpStr = "[WARN! please check if this system is not looking future quotes]";
        if (stat.getSharpeRatio()<=1)
            tmpStr = "[BAD]";
        System.out.println("Sharpe Ratio    : "+stat.getSharpeRatio()+" "+tmpStr);
        System.out.println("-----------------------------------------------------");
        System.out.println("[end]");            
    }

   /**
    * Generates HTML statistics
    *
    */
   public void generateHTMLStatistics(String fileName){
        Writer htm = null;
        try {
                htm = new Writer(fileName);
        } catch (IOException e) {
            System.out.println("Cannot write file "+fileName);
            System.exit(1);
        }
        htm.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
        htm.write("<HTML lang=\"en\">");
        htm.write("<head>");
        htm.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">");
        htm.write("<title>Statistics</title>");
        htm.write("</head>");        
        htm.write("<BODY>");
        htm.write("<STYLE>");
        htm.write("body  {background-color: white;font-family: sans-serif;font-size: small;color: darkblue;}");
        htm.write("table {background-color: gray;font-size: 12px;color: black;}");
        htm.write("p {font-size: medium;letter-spacing:2;font-weight: bold;color: gray;}");
        htm.write("p.copy {font-size: 10;letter-spacing:2;color: gray;}");

        htm.write("</STYLE>");
        htm.write("<BR><BR><center>");
        htm.write("<p>Statistics</p>");

        htm.write("<TABLE cellspacing=\"1\" cellpadding=\"3\" border=\"0\" width=\"80%\">");
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD width=\"25%\"><b>Initial Capital</b></TD>");
            htm.write("<TD width=\"25%\" bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getInitialCapital()+"</TD>");
            htm.write("<TD width=\"25%\"></TD>");
            htm.write("<TD width=\"25%\" bgcolor=\"#FFFCE8\"></TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Ending Capital</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getEndingCapital()+"</TD>");
            htm.write("<TD></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\"></TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Gross Profit</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getGrossProfit()+" ("+stat.getGrossSystemProfitPercent()+"%)"+"</TD>");
            htm.write("<TD><b>Tot Comm&Slipp</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+(stat.getGrossProfit()-stat.getNetProfit())+" ("+stat.getPercent((stat.getGrossProfit()-stat.getNetProfit()),stat.getGrossProfit())+"%)"+"</TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Net Profit</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getNetProfit()+" ("+stat.getNetSystemProfitPercent()+"%)"+"</TD>");
            htm.write("<TD></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\"></TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Net win amount</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getNetWinAmount()+"</TD>");
            htm.write("<TD></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\"></TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Net loss amount</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getNetLossAmount()+"</TD>");
            htm.write("<TD></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\"></TD>");        
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Buy&Hold (net)</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getBHProfit()+" ("+stat.getPercent(stat.getBHProfit(),stat.getInitialCapital())+"%)"+"</TD>");
            htm.write("<TD></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\"></TD>");        
        htm.write("</TR>");         
        htm.write("</TABLE>");

        htm.write("<BR>");

        htm.write("<TABLE cellspacing=\"1\" cellpadding=\"3\" border=\"0\" width=\"80%\">");
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD width=\"25%\"><b>Total Trades</b></TD>");
            htm.write("<TD width=\"25%\" bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getTradesCount()+"</TD>");
            htm.write("<TD width=\"25%\"></TD>");
            htm.write("<TD width=\"25%\" bgcolor=\"#FFFCE8\"></TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Wins</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getWinTrades()+" ("+stat.getWinPercent()+"%)"+"</TD>");
            htm.write("<TD><b>Consecutive wins</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getMaxConsecutiveWinner()+"</TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\"></TD>");
            htm.write("<TD><b>Max wins</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getMaxWinner()+ " ("+stat.getPercent(stat.getMaxWinner(),stat.getInitialCapital())+"%)"+"</TD>");            
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Losses</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getLossTrades()+" ("+stat.getLossPercent()+"%)"+"</TD>");
            htm.write("<TD><b>Consecutive losses</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getMaxConsecutiveLosers()+"</TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\"></TD>");
            htm.write("<TD><b>Max losses</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getMaxLoser()+ " ("+stat.getPercent(stat.getMaxLoser(),stat.getInitialCapital())+"%)"+"</TD>");            
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD colspan=\"2\" align=\"center\"><b>Long Trades</b></TD>");
            htm.write("<TD colspan=\"2\" align=\"center\"><b>Short Trades</b></TD>");            
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Wins</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getWinLongTrades()+" ("+stat.getWinLongPercent()+"%)"+"</TD>");
            htm.write("<TD><b>Wins</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getWinShortTrades()+" ("+stat.getWinShortPercent()+"%)"+"</TD>");            
        htm.write("</TR>");                 
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Losses</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getLossLongTrades()+" ("+stat.getLossLongPercent()+"%)"+"</TD>");
            htm.write("<TD><b>Losses</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getLossShortTrades()+" ("+stat.getLossShortPercent()+"%)"+"</TD>");            
        htm.write("</TR>");                 
        htm.write("</TABLE>");
        
        htm.write("<BR>");

        htm.write("<TABLE cellspacing=\"1\" cellpadding=\"3\" border=\"0\" width=\"80%\">");
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD width=\"25%\"><b>System DrawDown</b></TD>");
            htm.write("<TD width=\"25%\" bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getDrawDown()+"    ("+stat.getDrawDownPercent()+"%)"+"</TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Profit Factor</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getProfitFactor()+"</TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Average Profit</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getAverageProfitMean()+"</TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Average Profit %</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getAverageProfitPercent()+"%</TD>");
        htm.write("</TR>");         
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Standard Deviation</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getStdDev()+"</TD>");
        htm.write("</TR>");                                
        htm.write("<TR bgcolor=\"#FEFDD6\">");
            htm.write("<TD><b>Sharpe Ratio</b></TD>");
            htm.write("<TD bgcolor=\"#FFFCE8\" align=\"right\">"+stat.getSharpeRatio()+"</TD>");
        htm.write("</TR>");                 
        htm.write("</TABLE>");
        

        // close HTML file
        htm.write("<BR>");
        htm.write("<p class=\"copy\">&copy <a href=\"http://www.sourceforge.net/projects/sfljtse\" alt=\"\"><b>sfljTSE</b></a> opensource</p>");
        htm.write("</center></BODY>");
        htm.write("</HTML>");
        try {
            htm.close();
        } catch (IOException e) {
            System.out.println("Cannot close file "+fileName);
        }  
   } 

   
   /**
    * Generates Equity chart
    * @param fileName
    */
   public void generateEquity(String fileName){
       // TODO
       
   }
   
    /**
     * Writes statistics on file (ovverriding above method)
     * @param reportFileName String
     * @return boolean 
     */
    public boolean generateStatistics(String reportFileName){
    
        //  produce an HTML page with statistics
        System.out.println("Generating HTML report "+reportFileName+".html");
        // TODO: create class Report 
        return true;
    }
     
    /**
     * Generate a tradelsit and display it on standard output
     */
    public void generateTradeList(){
        generateTradeList(false,"");
    }
        
    
    /**
     * Generate a simple HTML file with trade list
     * @param fileName
     */
    public boolean generateHTMLTradeList(String fileName){
        generateTradeList(true,fileName);
        return true;
    }

    
    
    /**
     * Generate TradeList
     * @param html boolean, if true generate an HTML
     * @param fileName string
     */
    private void generateTradeList(boolean html,String fileName){
        String action1;
        String action2;
        Writer htm = null;
        
        double cum  = stat.getInitialCapital();
        double singleProfit     = 0;
        double singlePercent    = 0;
        double slipComm         = 0;
        double slipCommCum      = 0;
        double singlePercentCum = 0;
        
        
        if (html){
            try {
                htm = new Writer(fileName);
            } catch (IOException e) {
                System.out.println("Cannot write file "+fileName);
                System.exit(1);
            }
            htm.write("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
            htm.write("<HTML lang=\"en\">");
            htm.write("<head>");
            htm.write("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=ISO-8859-1\">");
            htm.write("<title>TradeList</title>");
            htm.write("</head>");        
            htm.write("<BODY>");
            htm.write("<STYLE>");
            htm.write("body  {background-color: white;font-family: sans-serif;font-size: small;color: darkblue;}");
            htm.write("table {background-color: gray;font-size: 12px;color: black;}");
            htm.write("p {font-size: medium;letter-spacing:2;font-weight: bold;color: gray;}");
            htm.write("p.copy {font-size: 10;letter-spacing:2;color: gray;}");

            htm.write("</STYLE>");
            htm.write("<BR><BR><center>");
            htm.write("<p>Trades List</p>");
            htm.write("<TABLE cellspacing=\"1\" cellpadding=\"1\" border=\"0\" width=\"80%\">");
            htm.write("<TR bgcolor=\"#FEFDD6\">");
                htm.write("<TD><b>N.</b></TD>");
                htm.write("<TD><b>Entry</b></TD>");
                htm.write("<TD><b>Date</b></TD>");
                htm.write("<TD><b>Time</b></TD>");
                htm.write("<TD><b>Type</b></TD>");
                htm.write("<TD><b>Price</b></TD>");
                htm.write("<TD><b>Qty</b></TD>");
                htm.write("<TD><b>Exit</b></TD>");
                htm.write("<TD><b>Date</b></TD>");
                htm.write("<TD><b>Time</b></TD>");
                htm.write("<TD><b>Price</b></TD>");
                htm.write("<TD><b>Qty</b></TD>");
                htm.write("<TD><b>NetProfit</b></TD>");
                htm.write("<TD><b>NetProfit%</b></TD>");
                htm.write("<TD><b>NetCum</b></TD>");
                htm.write("<TD><b>NetCum%</b></TD>");
                htm.write("<TD><b>CommSlip</b></TD>");
                htm.write("<TD><b>CommSlipCum</b></TD>");
            htm.write("</TR>");
        } else // std out
            System.out.println("N. ENTRY DATE\tTIME\tTYPE PRICE\tQTY\tOUT\tDATE\tTIME\tPRICE\tQTY\tNetGain NetGain% NetCUM NetCUM% CommSlip CommSlipCUM");

        
        for(int i=0;i<trades.size();i++){
            Trade trade = (Trade) trades.get(i);
            
            if (trade.getPositionType().get()==PositionType.LONG){
                action1 = "BUY  ";
                action2 = "SELL ";
                double slipStartComm = tAccount.calcCommission(trade.getStartQty()*trade.getStartPrice());
                double slipEndComm = tAccount.calcCommission(trade.getEndQty()*trade.getEndPrice());
                slipComm = slipStartComm + slipEndComm;
                singleProfit = (-1)*((trade.getStartPrice()*trade.getStartQty())-(trade.getEndPrice()*trade.getEndQty())) - slipComm;
                cum += singleProfit;
                slipCommCum += slipComm;
            }
            else {
                action1 = "SELL ";
                action2 = "COVER";
                double slipStartComm = tAccount.calcCommission(trade.getStartQty()*trade.getStartPrice());
                double slipEndComm = tAccount.calcCommission(trade.getEndQty()*trade.getEndPrice());
                slipComm = slipStartComm + slipEndComm;
                singleProfit = ((trade.getStartPrice()*trade.getStartQty())-(trade.getEndPrice()*trade.getEndQty())) - slipComm;
                cum += singleProfit;
                slipCommCum += slipComm;
            }
            
            //singlePercent = stat.getPercent(singleProfit,(trade.getStartPrice()*trade.getStartQty()));
            singlePercent = stat.getPercent(singleProfit,stat.getInitialCapital());
            singlePercentCum += singlePercent;
            
            if (!html){
                // STDOUT
                System.out.print(i+". "+action1+" ");
                System.out.print(Common.formatDate(trade.getStartDate()) +   "\t");
                System.out.print(trade.getStartTime() +   " ");
                System.out.print(trade.getPositionType().toString()   + "\t");
                System.out.print(Common.round(trade.getStartPrice(),4)+   "\t");
                System.out.print(trade.getStartQty()  +   "   "+action2+" ");
                System.out.print(Common.formatDate(trade.getEndDate())   +   "\t");
                System.out.print(trade.getEndTime()   +   "\t");
                System.out.print(Common.round(trade.getEndPrice(),4)  +   "\t");
                System.out.print(trade.getEndQty()    +   "\t");
                
                System.out.print(Common.round(singleProfit,2) + "\t");
                System.out.print(Common.round(singlePercent,2) + "%\t");
                System.out.print(Common.round(cum,2)  + "\t");
                System.out.print(Common.round(singlePercentCum,2)  + "%\t");
                System.out.print(slipComm + "\t");
                System.out.print(slipCommCum + "\t");
                System.out.println();
            } else {
                // HTML
                if (singleProfit<0)
                    htm.write("<TR bgcolor=\"#FFCAC4\">");
                else
                    htm.write("<TR bgcolor=\"#C7FDC6\">");
                    
                    htm.write("<TD>"+i+". "+"</TD>");
                    htm.write("<TD>"+action1+"</TD>");
                    htm.write("<TD>"+Common.formatDate(trade.getStartDate())+"</TD>");
                    htm.write("<TD>"+trade.getStartTime() +"</TD>");
                    htm.write("<TD>"+trade.getPositionType().toString()   + "</TD>");
                    htm.write("<TD align=\"right\">"+Common.round(trade.getStartPrice(),4) + "</TD>");
                    htm.write("<TD>"+trade.getStartQty()  + "</TD>");
                    htm.write("<TD>"+action2+"</TD>");
                    htm.write("<TD>"+Common.formatDate(trade.getEndDate()) +"</TD>");
                    htm.write("<TD>"+trade.getEndTime()   +"</TD>");
                    htm.write("<TD align=\"right\">"+Common.round(trade.getEndPrice(),4)  +"</TD>");
                    htm.write("<TD>"+trade.getEndQty() +"</TD>");
                
                    htm.write("<TD align=\"right\">"+Common.round(singleProfit,2) +"</TD>");
                    htm.write("<TD align=\"right\">"+Common.round(singlePercent,2) +"%"+"</TD>");
                    htm.write("<TD align=\"right\">"+Common.round(cum,2)  +"</TD>");
                    htm.write("<TD align=\"right\"><b>"+Common.round(singlePercentCum,2)  + "%"+"</b></TD>");
                    htm.write("<TD align=\"right\">"+slipComm +"</TD>");
                    htm.write("<TD align=\"right\">"+slipCommCum +"</TD>");
                
                htm.write("</TR>");
            } // end if
            
        }    // end for
        

        // close HTML file
        if (html){
            htm.write("</TABLE><BR>");
            htm.write("<p class=\"copy\">&copy <a href=\"http://www.sourceforge.net/projects/sfljtse\" alt=\"\"><b>sfljTSE</b></a> opensource</p>");
            htm.write("</center></BODY>");
            htm.write("</HTML>");
            try {
                htm.close();
            } catch (IOException e) {
                System.out.println("Cannot close file "+fileName);
            }
        }

        
    } // end method
    
    
    /**
     * Generate a simple XML file with trade list
     * @param fileName
     */
    public boolean generateXMLTradeList(String fileName){
        // TODO
        return true;
    }

        
}
