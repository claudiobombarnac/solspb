/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.stats;

import sfljtse.utils.Common;

/**
 * @title		: Stats       
 * @description	: Statistics class
 * @date		: Jul 12, 2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Stats {

    
    /**
     * Initial/ending capital
     */
    private double initialCapital  = 0;
    private double endingCapital   = 0;
    
    /**
     * Defines the number of trades that have been done
     */
    private int tradesCount     = 0;

    /**
     * The number of wins of Long
     */   
    private int winLongTradesCount  = 0;

    /**
     * The number of wins of Short
     */   
    private int winShortTradesCount  = 0;
    
    /**
     * The number of wins
     */
    private int winTradesCount  = 0;
    
    /**
     * The number of losses
     */
    private int lossTradesCount = 0;
    
    /**
     * The number of long trades
     */
    private int longTradesCount  = 0;
    
    /**
     * The number of short trades
     */
    private int shortTradesCount = 0; 
   
    /**
     * System net/gross profit
     */
    private double netProfit   = 0;
    private double grossProfit = 0;
    
    
    /**
     * Losses amount
     */
    private double lossNetAmount    = 0;
    private double lossGrossAmount  = 0;

    /**
     * Wins amount
     */
    private double winNetAmount     = 0;
    private double winGrossAmount   = 0;

    
    /**
     * Profit Factor
     */
    private double profityFactor = 0;
    
    /**
     * Standard Deviation
     */
    private double stdDev = 0;
    
    /**
     * Sum of profit percent
     */
    private double sumNetProfitPercent = 0;
    private double sumGrossProfitPercent = 0;

    /*
     * DrawDown
     */
    private double drawdown = 0;
    private double drawdownPercent  = 0;
    
    /**
     * Max consecutive wins and loses
     */
    private int maxConsecutiveWinner = 0;
    private int maxConsecutiveLoser  = 0;
    
    /**
     * Max Loser/winner trade
     */
    private double maxWinner = 0;
    private double maxLoser  = 0;
    
    /*
     * Sharpe Rate 
     */
    private double sharpeRatio = 0;
    
    /**
     * Buy & Hold strategy ( net )
     */
    private double BHnetProfit = 0;
    
    /**
     * Returns percentage of winning trades
     * @return double
     */
    public double getWinPercent(){
        double den = (winTradesCount+lossTradesCount);
        if (den==0)
            return 0;
        else
            return Common.round((winTradesCount/den)*100,2);
    }

    /**
     * Returns a percentage of a given value and its total
     * @param amount
     * @param total
     * @return
     */
    public double getPercent(double amount,double total){
        if (amount==0)
            return 0;
        else
            return Common.round((amount/total)*100,2);
    }
    
    
    /**
     * Returns percentage of losing trades
     * @return double
     */
    public double getLossPercent(){
        return Common.round(100-getWinPercent(),2);
    }

    /**
     * Returns percentage of winning trades from long side
     * @return double
     */
    public double getWinLongPercent(){
        double den = (winLongTradesCount+this.getLossLongTrades());
        if (den==0)
            return 0;
        else
            return Common.round((winLongTradesCount/den)*100,2);        
    }
    
    /**
     * Returns percentage of losses trades from Long side
     * @return
     */
    public double getLossLongPercent(){
        return Common.round(100-this.getWinLongPercent(),2);
    }

    
    /**
     * Returns percentage of winning trades from short side
     * @return double
     */
    public double getWinShortPercent(){
        double den = (winShortTradesCount+this.getLossShortTrades());
        if (den==0)
            return 0;
        else
            return Common.round((winShortTradesCount/den)*100,2);        
    }
    
    /**
     * Returns percentage of losses trades from short side
     * @return
     */
    public double getLossShortPercent(){
        return Common.round(100-this.getWinShortPercent(),2);
    }

    
    
    /**
     * Update net profit
     * @param partialNetProfit double
     */
    public void updateNetProfit(double partialNetProfit){
        netProfit += partialNetProfit;
    }

    /**
     * Update gross profit
     * @param partialGrossProfit double
     */
    public void updateGrossProfit(double partialGrossProfit){
        grossProfit += partialGrossProfit;
    }
    
    
    
    /**
     * Update net loss amount
     * @param loss
     */
    public void updateNetLossAmount(double loss){
        lossNetAmount  += loss;
    }

    /**
     * Update gross loss amount
     * @param loss
     */
    public void updateGrossLossAmount(double loss){
        lossGrossAmount  += loss;
    }

    /**
     * Update net win amount 
     * @param win
     */
    public void updateNetWinAmount(double win){
        winNetAmount  += win;
    }

    /**
     * Update gross win amount 
     * @param win
     */
    public void updateGrossWinAmount(double win){
        winGrossAmount  += win;
    }
    
    /**
     * Gets net profit
     * @return netProfit double
     */
    public double getNetProfit(){
        return Common.round(netProfit,2);
    }

    /**
     * Gets gross profit
     * @return netProfit double
     */
    public double getGrossProfit(){
        return Common.round(grossProfit,2);
    }
    
    /**
     * Increments number of trades
     */
    private void incTradesCount(){
        tradesCount++;
    }
    
    /**
     * Returns number of trades 
     * @return int
     */
    public int getTradesCount(){
        return tradesCount;
    }
    
    /**
     * Increments number of win trades
     */
    public void incWinTrades(){
        winTradesCount++;
    }
    
    /**
     * Returns number of win trades 
     * @return int
     */
    public int getWinTrades(){
        return winTradesCount;
    }

    /**
     * Increments number of winning trades from long side
     */
    public void incWinLongTrades(){
        winLongTradesCount++;
    }
    
    /**
     * Returns a number of winning trades from long side
     * @return int
     */
    public int getWinLongTrades(){
        return winLongTradesCount;
    }
    
    /**
     * Returns number of loss trades from long side 
     * @return
     */
    public int getLossLongTrades(){
        return longTradesCount-winLongTradesCount;
    }

    
    /**
     * Increments number of winning trades from short side
     */
    public void incWinShortTrades(){
        winShortTradesCount++;
    }
    
    /**
     * Returns a number of winning trades from long side
     * @return int
     */
    public int getWinShortTrades(){
        return winShortTradesCount;
    }
    
    /**
     * Returns number of loss trades from long side 
     * @return
     */
    public int getLossShortTrades(){
        return shortTradesCount-winShortTradesCount;
    }
    
    
    /**
     * Increments number of losses trades
     */
    public void incLossTrades(){
        lossTradesCount++;
    }
    
    /**
     * Returns number of losses trades 
     * @return int
     */
    public int getLossTrades(){
        return lossTradesCount;
    }
    
    /**
     * Increments number of long trades
     */
    public void incLongTrades(){
        longTradesCount++;
        incTradesCount();
    }
    
    /**
     * Returns number of long trades 
     * @return int
     */
    public int getLongTrades(){
        return longTradesCount;
    }
    
    /**
     * Increments number of short trades
     */
    public void incShortTrades(){
        shortTradesCount++;
        incTradesCount();
    }
    
    /**
     * Returns number of short trades 
     * @return int
     */
    public int getShortTrades(){
        return shortTradesCount;
    }

    
    /**
     * Gets return percentage on initial capital
     * @return double 
     */
    public double getNetSystemProfitPercent(){
        double den = (this.initialCapital/100);
        if (den==0)
            return 0;
        else
            return Common.round((netProfit/den),2);
    }

    /**
     * Gets return percentage on initial capital
     * @return double 
     */
    public double getGrossSystemProfitPercent(){
        double den = (this.initialCapital/100);
        if (den==0)
            return 0;
        else
            return Common.round((grossProfit/den),2);
    }
    
    /**
     * Sets initial capital
     * @param amount
     */
    public void setInitialCapital(double amount){
        this.initialCapital = amount;
    }
    
    /**
     * Gets Initial capital
     * @return double
     */
    public double getInitialCapital(){
        return this.initialCapital;
    }
    
    /**
     * Sets ending capital
     * @param amount
     */
    public void setEndingCapital(double amount){
        this.endingCapital = amount;
    }
    
    /**
     * Gets ending capital
     * @return
     */
    public double getEndingCapital(){
        return this.endingCapital;
    }
    
    /**
     * Gets net loss amount
     * @return
     */
    public double getNetLossAmount(){
        return Common.round(this.lossNetAmount,2);
    }

    /**
     * Gets net gross amount
     * @return
     */
    public double getGrossLossAmount(){
        return Common.round(this.lossGrossAmount,2);
    }
    
    /**
     * Gets net win amount
     * @return
     */
    public double getNetWinAmount(){
        return Common.round(this.winNetAmount,2);
    }

    /**
     * Gets gross win amount
     * @return
     */
    public double getGrossWinAmount(){
        return Common.round(this.winGrossAmount,2);
    }
    
    /**
     * Gets profit factor ( based on Gross )
     * @return
     */
    public double getProfitFactor(){
        if (this.lossGrossAmount!=0)
            return Common.round((-this.winGrossAmount/this.lossGrossAmount),2);
        else
            return 0;
    }
    
    /**
     * Does arithmetic mean of average profit
     * @return
     */
    public double getAverageProfitMean(){
        double mean;
        if (tradesCount!=0)
            mean = this.getNetProfit()/this.tradesCount;
        else
            mean = 0;
        
        return Common.round(mean,2);
    }
    
    
    /**
     * Sum of profit percent (based on net)
     * @param amount
     */
    public void setSumNetProfitPercent(double amount){
        sumNetProfitPercent = amount;
    }
    
    /**
     * Average of profit percent
     * @return
     */
    public double getAverageProfitPercent(){
        // SumProfitPct / PositionCount
        double avgP = 0;
        if (tradesCount!=0)
            avgP = (sumNetProfitPercent/tradesCount);
        return Common.round(avgP,2);
    }
    
    /**
     * Sets standard deviation
     * @param stdDev
     */
    public void setStdDev(double stdDev){
        this.stdDev = stdDev;
    }
    
    /**
     * gets standard deviation 
     * @return
     */
    public double getStdDev(){
        return Common.round(stdDev,2);
    }
    
    /**
     * Sets max drawdown
     * @param dd
     */
    public void setDrawDown(double dd){
        this.drawdown = dd;
    }
    
    /**
     * gets max Drawdown
     * @return
     */
    public double getDrawDown(){
        return Common.round(this.drawdown,2);
    }
    
    /**
     * gets drawdown percent
     * @return
     */
    public double getDrawDownPercent(){
        if (this.netProfit!=0)
            return this.drawdownPercent = Common.round((this.drawdown/this.initialCapital)*100,2);
        else
            return 0;
    }
    
    /**
     * Gets Max consecutive wins
     * @return
     */
    public int getMaxConsecutiveWinner(){
        return this.maxConsecutiveWinner;
    }
 
    /**
     * sets max consecutive wins
     */
    public void setMaxConsecutiveWinner(int cw){
        this.maxConsecutiveWinner = cw;
    }
    
    /**
     * Gets Max consecutive loses
     * @return
     */
    public int getMaxConsecutiveLosers(){
        return this.maxConsecutiveLoser;
    }
 
    /**
     * sets max consecutive loses
     */
    public void setMaxConsecutiveLoser(int cl){
        this.maxConsecutiveLoser = cl;
    }
    
    /**
     * gets max winner/loser trade
     * @return
     */
    public double getMaxWinner(){
        return Common.round(this.maxWinner,2);
    }
    public double getMaxLoser(){
        return Common.round(this.maxLoser,2);
    }
    
    /**
     * Sets max winner / loser
     * @param maxWin
     */
    public void setMaxWinner(double maxWin){
        this.maxWinner = maxWin;
    }
    public void setMaxLoser(double maxLos){
        this.maxLoser = maxLos;
    }
    
    /**
     * Sets Sharpe Ratio
     * @param sr
     */
    public void setSharpeRatio(double sr){
        this.sharpeRatio = sr;
    }
    
    /**
     * Gets Sharpe Ratio
     * @return
     */
    public double getSharpeRatio(){
        return Common.round(this.sharpeRatio,2);
    }
    
    /**
     * Gets B&H (net)
     * NOTE: B&H is calculated from first entry trade to last.
     * @return double
     */
    public double getBHProfit(){
        return Common.round(this.BHnetProfit,2);
    }
    
    /**
     * Sets B&H net profit
     * @param BHnetProfit
     */
    public void setBHProfit(double BHnetProfit){
        this.BHnetProfit = BHnetProfit;
    }
    
} // end stat class

