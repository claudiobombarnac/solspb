/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.stats;

import sfljtse.trader.PositionType;

/**
 * @title		: Trade       
 * @description	:  
 * @date		: 14-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Trade {

     public static byte status_CLOSED    = 1;
     public static byte status_OPEN      = 2;
     public static byte status_REDUCED   = 3;
     public static byte status_INCREASED = 4;
     
    
     private PositionType positionType = new PositionType();
     private int    startDate   = 0;
     private int    startTime   = 0;
     private double startPrice  = 0;
     private int    startQty    = 0;
     private int    endDate     = 0;
     private int    endTime     = 0;
     private double endPrice    = 0;
     private int    endQty      = 0;
     private byte   status      = 0;
     
     
     public void setStatus(byte statusType){
         this.status = statusType;
     }
     
     public void setPositionType(int positionType){
         this.positionType.set(positionType);
     }
     
     public void setStartDate(int startDate){
      this.startDate = startDate;   
     }
     
     public void setStartTime(int startTime){
         this.startTime = startTime;
     }
     
     public void setStartPrice(double startPrice){
         this.startPrice = startPrice;
     }
     
     public void setStartQty(int startQty){
         this.startQty = startQty;
     }
          
     public void setEndDate(int endDate){
      this.endDate = endDate;   
     }
     
     public void setEndTime(int endTime){
         this.endTime = endTime;
     }
     
     public void setEndPrice(double endPrice){
         this.endPrice = endPrice;
     }
     
     public void setEndQty(int endQty){
         this.endQty = endQty;
     }

     public PositionType getPositionType(){
         return positionType;
     }

     public byte getStatus(){
         return status;
     }
     
     public int getStartDate(){
         return startDate;
     }

     public int getStartTime(){
         return startTime;
     }
     
     public double getStartPrice(){
         return startPrice;
     }

     public int getStartQty(){
         return startQty;
     }

     public int getEndDate(){
         return endDate;
     }

     public int getEndTime(){
         return endTime;
     }
     
     public double getEndPrice(){
         return endPrice;
     }

     public int getEndQty(){
         return endQty;
     }

       
     
}
