/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.stats;

import java.util.LinkedList;

/**
 * @title		: TradeList       
 * @description	: Keep a list for all trades, usefull for statistics 
 * @date		: 14-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class TradeList {
    
    private LinkedList trades = new LinkedList();   
    
    
    /**
     * Returns a full list of trades
     * @return LinkedList
     */
    public LinkedList getFullTradeList(){
        return trades;
    }
    
    /**
     * Gets a single trade
     * @param item int
     * @return Trade
     */
    public Trade getTrade(int item){
        return (Trade) trades.get(item);
    }
    
  
    
    /**
     * Add a closed trade
     * @param positionType
     * @param startDate
     * @param startTime
     * @param startPrice
     * @param startQty
     * @param endDate
     * @param endTime
     * @param endPrice
     * @param endQty
     * @param status
     */
    public void addTrade(int positionType,int startDate,int startTime,double startPrice,int startQty,int endDate,int endTime,double endPrice,int endQty,byte status){
        Trade trade = new Trade();
        
        trade.setPositionType(positionType);

        // start values
        trade.setStartDate(startDate);
        trade.setStartTime(startTime);
        trade.setStartPrice(startPrice);
        trade.setStartQty(startQty);
        
        // end values
        trade.setEndDate(endDate);
        trade.setEndTime(endTime);
        trade.setEndPrice(endPrice);
        trade.setEndQty(endQty);

        trade.setStatus(status);
        
        trades.addLast(trade);
    }
    
}
