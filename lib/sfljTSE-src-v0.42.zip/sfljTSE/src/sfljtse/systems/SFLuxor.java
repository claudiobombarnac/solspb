/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.systems;

import sfljtse.systems.model.ASystem;
import sfljtse.systems.model.ISystem;
import sfljtse.trader.ISignal;
import sfljtse.ta.averages.T3;

/**
 * @title		: SFLuxor       
 * @description	: Luxor clone
 * @date		: 22-set-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class SFLuxor extends ASystem implements ISystem {

    private double[] high;
    private double[] low;
    
    private int    hPeriods    = 12;
    private int    lPeriods    = 12;
    private double hNoise      = 0.04;
    private double lNoise      = 0.04;

    
   
    /**
     * Constructor 1
     */
    public SFLuxor() {
        this.systemName         = "SFLuxor";
        this.systemDescription  = "SFLuxor system)";
        this.systemAuthor       = "sfl";
        this.showInfo();        
    }

    /**
     * Constructor 2
     * @param configFile
     */
    public SFLuxor(String configFile) {
        super(configFile);
        // TODO Auto-generated constructor stub
    }

    /**
     * @override ASystem.engine()
     * 
     * Write system's rules here!
     * 
     */
    public void engine(){        
        init();
        rules();
    } // end engine
       
    
    
    /**
     * Inits
     */
    private void init(){

        high = new double[price.getSize()];
        low  = new double[price.getSize()];
        
        for (int i=price.getFirst();i<price.getLast()-1;i++){
            high[i] = price.getHigh(i);
            low[i] = price.getLow(i);
        }
        
        // load from outside
        hPeriods    = 24;
        lPeriods    = 24;
        hNoise      = 0.03;
        lNoise      = 0.03;
    }
    
    /**
     *  System's rules
     */
    private void rules(){
        double hi   = 0.0;
        double lo   = 0.0;
        double mid  = 0.0;
        boolean isUP    = false;
        boolean isDOWN  = false;
        boolean isNOISY = false;
        boolean dailyUPSignal   = false;
        boolean dailyDOWNSignal = false;
        
        // calcs the channel, 
        T3 t3hi = new T3(high,hPeriods,T3.EMA);
        T3 t3lo = new T3(low,lPeriods,T3.EMA);
        
        for (int i=price.getFirst()+hPeriods+5;i<price.getLast()-1;i++){

            // init dailyXXXSignal
            dailyUPSignal   = false;
            dailyDOWNSignal = false;
            
            hi  = t3hi.ma[i] + hNoise;
            lo  = t3lo.ma[i] - lNoise;
            mid = lo+((hi-lo)/2);

            /**
             * get trend tendency, UP, DOWN and NOISY
             * NOISY means that current dailyXXXSignal is still valid,
             * but the direction or the strnght of current trend is going weak,
             * this also means congestion zone.
             */ 
            isUP    = price.getClose(i) > hi;
            isDOWN  = price.getClose(i) < lo;
            isNOISY = (price.getClose(i) >= lo) && (price.getClose(i) <= hi);
            
            // get trend signal ( UP and DOWN )
            if (isUP){
                dailyUPSignal   = true;
                dailyDOWNSignal = false;
            } else {
                dailyUPSignal   = false;
                dailyDOWNSignal = true;                
            }
            
            /**
             * LONG SIGNALS
             */
            // BUY
            if (dailyUPSignal){
                qty = 5000;
                // Buy at tomorrow's open               
                //signal.Cover(price.getOpen(i+1),price.getDate(i+1),qty);
                //signal.Buy(price.getOpen(i+1),price.getDate(i+1),qty);
                signal.reverse(ISignal.SHORT,price.getOpen(i+1),price.getDate(i+1),qty);
            }
            // SELL
            if (dailyDOWNSignal){
                qty = 5000;
                // Buy at tomorrow's open
                //signal.Sell(price.getOpen(i+1),price.getDate(i+1),qty);
                //signal.Short(price.getOpen(i+1),price.getDate(i+1),qty);
                signal.reverse(ISignal.LONG,price.getOpen(i+1),price.getDate(i+1),qty);
            }                        
            // -----------------------------
            
        } // end for


        
    } // end engine method
    
    
} // end class system
