/*
 * SFL java Trading System Enviroment
 * Copyright (C) 2004 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.systems.model;

import sfljtse.alarms.Alarm;
import sfljtse.quotes.Price;
import sfljtse.settings.LoadXMLConfiguration;
import sfljtse.stats.Equity;
import sfljtse.trader.Account;
import sfljtse.trader.Commission;
import sfljtse.trader.Signal;
import sfljtse.trader.TradeAccount;
import sfljtse.utils.Timer;


/**
 * @title		: ASystem       
 * @description	: Abstract System class
 * @date		: 29-July-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public abstract class ASystem{

    protected String systemName 	     = "";
    protected String systemAuthor	     = "";
    protected String systemDescription = "";

    /*
     * Needed quotes
     */
    protected int requiredQuotes = 1;
    
    // prices
    protected double buyPrice     = 0;
    protected int    buyDate      = 0;
    protected int    buyTime      = 0;
    protected double sellPrice    = 0;
    protected int    sellDate     = 0;
    protected int    sellTime     = 0;
    
    protected double shortPrice   = 0;
    protected int    shortDate    = 0;
    protected int    shortTime    = 0;
    protected double coverPrice   = 0;
    protected int    coverDate    = 0;
    protected int    coverTime    = 0;

    protected int qty = 1;

    protected String symbol = ""; 
    protected LoadXMLConfiguration conf; 

    protected Price         price;
    protected Account       account;
    protected Commission    myCommission;
    protected TradeAccount  tradeAccount;
    protected Signal        signal;
    protected Alarm         alarm;
    
    
    /**
     * Constructor 
     */
    public ASystem(){};

    
    /**
     * Constructor 
     * @param symbol
     */
    public ASystem(String configFile){
        conf = new LoadXMLConfiguration(configFile,true);
        // for each symbol in configuration file run this system
        for (int i=0;i<conf.getSymbols().length;i++){
            this.symbol = conf.getSymbols()[i];
            executeSystem();
        }
    }

    
    /**
     * Display Symbol name
     */
    protected void showSymbol(){
        System.out.println("///////////////////////////////");
        System.out.println("Processing  "+symbol+".. .");
        System.out.println("///////////////////////////////");
    }

    /**
     * Displays system's info
     */
    protected void showInfo(){
        System.out.println("-------------------------------------------------");
        System.out.println(" ID Name        : "+this.getClass().getSimpleName());
        System.out.println(" Full Name      : "+systemName);
        System.out.println(" Author         : "+systemAuthor);
        System.out.println(" Description    : "+systemDescription);
        System.out.println("-------------------------------------------------");

        // load report if present, check for systemame.xml in /reports/ directory
    }
    
    /**
     * Execute system
     */
    private void executeSystem(){
    
        // start timer
        Timer timer = new Timer();
        timer.startTimer();
        
        // displays symbol information
        showSymbol();
        
        /**
         * Loads Prices
         */
        price = conf.getPrices(symbol);        
        if (price.getSize()==0){
            System.out.println("No quotes founds for symbol "+symbol+", system can't works.");
            System.exit(1);
        }
                
        /**
         * Create a Bank Account
         */
        account = conf.getAccount();
        
        /**
         * Sets up commission plan
         */
        myCommission = conf.getCommissions();
        
        /**
         * Create TradeAccount and inits with money and commission
         */
        tradeAccount = new TradeAccount(conf.getTradeAccountAmount(account),myCommission);
        
        /**
         * Create Equity and initialize it with total amount of money in tradeAccount
         */
        Equity equity = new Equity(tradeAccount.getTotal());
        System.out.println("Initial Equity is "+equity.getInitialEquity());
        
        /**
         * Create System signals
         */
        signal = new Signal(tradeAccount);

        /**
         * Create Alarm oject
         */
        alarm = conf.getAlarms();
               
        
        /**
         * START SYSTEM CODE HERE
         * ---------------------------------------------------------------------
         */

        engine();
        
        /**
         * END SYSTEM CODE HERE
         * --------------------------------------------------------------------
         */
        
        
        
        /**
         * Generate Reports
         */        
        conf.getReports(signal,equity,this.getClass().getSimpleName());        

        // elapsed time
        System.out.println("\nDone in "+timer.stopTimer());
			
    }

   /**
    * System Engine, to be implemented in a real class
    */
    public void engine(){}
    
    
} // end system class
