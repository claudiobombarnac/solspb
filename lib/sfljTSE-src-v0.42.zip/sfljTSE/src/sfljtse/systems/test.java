/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.systems;

import sfljtse.systems.model.ASystem;
import sfljtse.systems.model.ISystem;

/**
 * @title		: test       
 * @description	:  
 * @date		: 29-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class test extends ASystem implements ISystem{
    
    /**
     * Constructor 1
     */
    public test() {
        this.systemName         = "test";
        this.systemDescription  = "A simple test system, do not use for real trading!";
        this.systemAuthor       = "sfl";
        this.showInfo();        
    }

    /**
     * Constructor 2
     * @param configFile
     */
    public test(String configFile) {
        super(configFile);
        // TODO Auto-generated constructor stub
    }

    
    
    /**
     * System engine
     */
    public void engine(){
        //  How to get data into LinkedList
        requiredQuotes = 20; 
        for (int i=requiredQuotes;i<price.getSize()-1;i++) {
        
            boolean myEntry = price.getClose(i)>price.getClose(i-1) && price.getOpen(i)<=price.getOpen(i-1);
            boolean myExit  = price.getClose(i)<price.getClose(i-1) && price.getOpen(i)<price.getOpen(i-1);
                         
            /**
             * If entry condition is verified, BUY
             * (i+1) means buy at tomorrow open
             */
            if ((myEntry)&&(signal.isFlat())){
                buyPrice    = price.getOpen(i+1); 
                buyDate     = price.getDate(i+1);
                buyTime     = price.getTime(i+1);
                // reinvest all capital
                //qty         = tradeAccount.investAllCapital(buyPrice);
                // invest always 40000
                //qty         = tradeAccount.investFor(buyPrice,40000);
                // invest a 80% of current account cash
                qty           = tradeAccount.investPercentOf(buyPrice,80);
                
                // Buy daily
                signal.Buy(buyPrice,buyDate,qty);
            }
            //-------------------------------------

            /**
             * If exit condition is verified, SELL
             */            
            if ((myExit)&&(signal.isLong())){
                sellPrice = price.getOpen(i+1);
                sellDate  = price.getDate(i+1);
                sellTime  = price.getTime(i+1);
                qty       = signal.portfolio.getQtyOfOpenTrade();
                // Sell daily
                signal.Sell(sellPrice,sellDate,qty);
            }
            //-------------------------------------
            
            
        } // end for                  
        
    }

    
}
