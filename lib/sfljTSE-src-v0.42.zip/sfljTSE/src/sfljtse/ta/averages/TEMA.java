/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.ta.averages;

import sfljtse.ta.averages.model.AbstractMA;
import sfljtse.ta.averages.model.IMA;

/**
 * @title		: TEMA       
 * @description	: Triple Exponential Moving Average  
 * @date		: Sep 5, 2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class TEMA extends AbstractMA implements IMA{

    public TEMA(double[] value, int periods) {
        super(value, periods);
        calc();
    }

    /**
     * Calculate triple exponential moving average
     * Based on EMA, the used formula is:
     * TEMA = 3 * EMA(Close,len) - 3 * EMA(EMA(Close,len),Len) + EMA(EMA(EMA(Close,len),len),len);
     * where len is periods.
     * TODO: so fucking slow!
     */
    public void calc() {
        int size = value.length;
        if(periods>size) {
            for (int i=0;i<size;i++)
                ma[i] = 0.0;   
        } else {      
            EMA ema  = new EMA(value,periods);
            for (int i=periods;i<size;i++){
                ma[i] = (3 * ema.ma[i]) - (3 * new EMA(ema.ma,periods).ma[i]) + new EMA(new EMA(ema.ma,periods).ma,periods).ma[i];
            }
        }
        
    }

  
}
