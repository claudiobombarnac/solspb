/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.trader;

/**
 * @title		: Account       
 * @description	: 
 * @date		: 8-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Account extends Bank implements IAccount {
       
    
    /**
     * Portfolio's Cash
     */
    private double cash = 0;

    /**
     * Portfolio's Total
     */
    private double total = 0;

    
    /**
     * Account's name
     */
    private String name = "";
    
    /**
     * Constructor 1
     */
    public Account(){
        
    }

    /**
     * Constructor
     * @param name
     * @param bank
     * @param cc
     * @param cash
     * @param valute
     */
    public Account(String name,String bank,String cc,double cash,String valute){
        this.setName(name);
        this.setBankName(bank);
        this.setCC(cc);
        this.setCash(cash);
        this.setValute(valute);
    }

    
    
    /* (non-Javadoc)
     * @see sfljtse.trader.IPortfolio#getTotal()
     */
    public double getTotal() {
        return total;
    }

    /* (non-Javadoc)
     * @see sfljtse.trader.IPortfolio#setTotal(double)
     */
    public boolean setTotal(double amount) {
        total = amount;
        return true;
    }

    /* (non-Javadoc)
     * @see sfljtse.trader.IPortfolio#getCash()
     */
    public double getCash() {
        return cash;
    }

    /* (non-Javadoc)
     * @see sfljtse.trader.IPortfolio#setCash(double)
     */
    public boolean setCash(double amount) {
        cash = amount;
        return true;
    }

    /* (non-Javadoc)
     * @see sfljtse.trader.IPortfolio#deposit(double)
     */
    public boolean deposit(double amount) {
        if (amount>0) {
            cash = cash + amount;
            total = total + amount;
            return true;
        } else
            return false;
    }

    /* (non-Javadoc)
     * @see sfljtse.trader.IPortfolio#withdraw(double)
     */
    public boolean withdraw(double amount) {
        double virtualCash =  cash - amount;
        if (virtualCash<0) 
            return false;
        else {
            cash = virtualCash;
            return true;
        }
    }


    /**
     *  (non-Javadoc)
     * @see sfljtse.trader.IPortfolio#getCashPercent(int)
     */
    public double getCashPercent(int percentage) {
        double cashTot = this.getCash();
        if (percentage>100)
            percentage = (percentage % 100);
        return ((cashTot/100)*percentage);
    }

    /**
     * Only for testing purpose
     * @param args
     */
    public static void main(String[] args) {
        Account fineco = new Account();
        fineco.deposit(10000);
        System.out.println("CASH="+fineco.getCash()+" TOTAL="+fineco.getTotal());
        fineco.withdraw(3000);
        System.out.println("CASH="+fineco.getCash()+" TOTAL="+fineco.getTotal());
    }

    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    
}
