/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.trader;

import java.util.Random;

/**
 * @title		: Commission       
 * @description	: Define account's commissions  
 * @date		: 8-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Commission {

    private double base         = 0;
    private double percentage   = 0;
    private double upto         = 0;
    private double slipPage     = 0; 
    
    /**
     * Constructor
     */
    public Commission(){
        // loads default from XML system config file?
    }
    
    /**
     * Constructor
     * @param base
     * @param percentage
     * @param upto
     * @param slippage
     */
    public Commission(double base,double percentage,double upto,double slippage){
        this.base       = base;
        this.percentage = percentage;
        this.upto       = upto;
        this.slipPage   = slippage;
    }
    
    
    /**
     * Sets base commission value
     * @param base
     */
    public void setBase(double base){
        this.base = base;
    }

    /**
     * Sets percentage
     * @param percentage
     */
    public void setPercentage(double percentage){
        this.percentage = percentage;
    }

    /**
     * Sets maximun commission value
     * @param upto
     */
    public void setUpTo(double upto){
        this.upto = upto;
    }

    /**
     * Gets base commission value
     * @return
     */
    public double getBase(){
        return base;
    }
    
    /**
     * Gets percenmtage
     * @return
     */
    public double getPercentage(){
        return percentage;
    }
    
    /**
     * Gets maximum commission value
     * @return
     */
    public double getUpTo(){
        return upto;
    }
    
    /**
     * Sets slippage
     * @param amount
     */
    public void setSlipPage(double amount){
        setFixSlipPage(amount);
    }

    /**
     * Sets fixed slipPage
     * @param amount
     */
    public void setFixSlipPage(double amount){
        this.slipPage = amount;
    }
    
    /**
     * Gets a random slippage between 0 and max value 
     * @param amount
     */
    public double getRndSlipPage(int max){
        return (new Random(max).nextDouble());
    }
    
    /**
     * Get slippage value
     * @return
     */
    public double getSlipPage(){
        return slipPage;
    }
    
}
