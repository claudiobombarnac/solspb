/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.trader;

/**
 * @title		: Position       
 * @description	:  
 * @date		: 7-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public interface ISignal {

    public static final int NOSIGNAL    = 0;
    public static final int BUY         = 1;
    public static final int SELL        = 2;
    public static final int SHORT       = 3;
    public static final int COVER       = 4;
    public static final int REVERSE     = 5;
    public static final int HOLD        = 6;
    public static final int LONG        = 7;
    public static final int FLAT        = 8;
    public static final int FAIL        = 9;
    public static final int NOCASH      = 10;


}
