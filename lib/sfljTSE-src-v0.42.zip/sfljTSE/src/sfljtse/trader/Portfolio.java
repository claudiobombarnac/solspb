/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.trader;

import java.util.LinkedList;

import sfljtse.stats.Trade;
import sfljtse.stats.TradeList;

/**
 * @title		: Portfolio       
 * @description	:  
 * @date		: 8-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Portfolio implements IPortfolio {

    private LinkedList trades   = new LinkedList();
    private TradeList tradeList;

       
    /**
     * Constructor
     * @param tradeList
     */
    public Portfolio(TradeList tradeList){
        this.tradeList = tradeList;
    }
    
    /**
     * Opens new Long Trade
     * @param date
     * @param time
     * @param price
     * @param qty
     */
    public void openLongTrade(int date,int time,double price,int qty){
        add(PositionType.LONG,date,time,price,qty,Trade.status_OPEN);
    }

    /**
     * Opens new Short Trade
     * @param date
     * @param time
     * @param price
     * @param qty
     */
    public void openShortTrade(int date,int time,double price,int qty){
        add(PositionType.SHORT,date,time,price,qty,Trade.status_OPEN);
    }

    /**
     * Closes Long trade
     * @param date
     * @param time
     * @param price
     * @param qty
     */
    public void closeLongTrade(int date,int time,double price,int qty){
        remove(PositionType.LONG,date,time,price,qty,Trade.status_OPEN);
    }

    /**
     * Closes Short trade
     * @param date
     * @param time
     * @param price
     * @param qty
     */
    public void closeShortTrade(int date,int time,double price,int qty){
        remove(PositionType.SHORT,date,time,price,qty,Trade.status_OPEN);
    }

    
    /**
     * Gets portfolio entries
     * @return
     */
    public LinkedList getPortfolioEntries(){
        return trades;
    }
    
    
    /**
     * Add a portafolio entry
     * @param positionType
     * @param date
     * @param time
     * @param price
     * @param qty
     * @param status
     */
    private void add(int positionType,int date,int time,double price,int qty,byte status){
        Trade trade = new Trade();
        
        trade.setPositionType(positionType);

        // start values
        trade.setStartDate(date);
        trade.setStartTime(time);
        trade.setStartPrice(price);
        trade.setStartQty(qty);
        
        trade.setStatus(status);
        
        trades.addLast(trade);
    }
    
    /**
     * Remove a portfolio entry
     * @param positionType
     * @param date
     * @param time
     * @param price
     * @param qty
     * @param status
     */
    private void remove(int positionType,int date,int time,double price,int qty,byte status){
        Trade trade;
        try{
            trade = (Trade) trades.getLast();
            tradeList.addTrade(positionType,trade.getStartDate(),trade.getStartTime(),trade.getStartPrice(),trade.getStartQty(),date,time,price,qty,Trade.status_CLOSED);
            trades.remove();
        } catch (Exception e){
            return;
        }
    }
    
    /**
     * Gets quantity of last open trade
     * @return
     */
    public int getQtyOfOpenTrade(){
        try {
            Trade trade = (Trade) trades.getLast();
            return trade.getStartQty();
        } catch (Exception e){
            return 0;
        }
        
    }
    
    /**
     * Only for testing purpose
     * @param args
     */
    public static void main(String[] args) {
 
    }
   
}
