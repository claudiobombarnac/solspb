/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.trader;

/**
 * @title		: PositionType       
 * @description	:  
 * @date		: 14-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class PositionType {
    public static int LONG     = 1;
    public static int SHORT    = 2;
    
    private int position;
    
    public void set(int positionType){
        position = positionType;
    }

    public int get(){
        return position;
    }
    
    public String toString(){
        switch (position){
        case 1: return "LONG";
        case 2: return "SHORT";
        default: return "";
        }
    }
}
