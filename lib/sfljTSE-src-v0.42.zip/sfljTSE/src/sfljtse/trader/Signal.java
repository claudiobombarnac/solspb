/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.trader;

import java.util.LinkedList;

import sfljtse.stats.Trade;
import sfljtse.stats.TradeList;
import sfljtse.utils.Common;


/**
 * @title		: Signal     
 * @description	: Manage system signals 
 * @date		: 7-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Signal {

    private boolean verbose = false;
    
    private int currentSignal;

    /**
     * Trade Account
     */
    public TradeAccount tAccount;

    
    /**
     * Portolio
     */
    public Portfolio portfolio;
    
    /**
     * TradeList
     */
    public TradeList tradeList = new TradeList();
   
    
    // sempahore structure, do not use it if you wanna 
    // open more then one position simultaneously
    private static boolean openLong    = false;
    private static boolean openShort   = false;
    
    
    /**
     * Constructor 
     * @param size (quote list dimension) int
     */
    public Signal(TradeAccount account){
        this.tAccount = account;
        initSystem();
    }

    /**
     * Constructor 
     * @param size (quote list dimension) int
     */
    public Signal(TradeAccount account,boolean verbose){
        this.tAccount = account;
        this.verbose  = verbose;  
        initSystem();
    }

    
    
    
    /**
     * Fire up!
     */
    private void initSystem(){
        currentSignal = ISignal.FLAT;
        portfolio = new Portfolio(tradeList);
    }
    
    /**
     * Return the type of currentopened position (long/short)
     * @return
     */
    public int currentPosition(){
        if (openLong) 
            return ISignal.LONG;
        if (openShort)
            return ISignal.SHORT;
        return ISignal.FLAT;
    }

    /**
     * get current position in string (human readable format), uppercase.
     * @return String uppercase
     */
    public String getStrCurrentPosition(){
        switch (currentPosition()){
        case ISignal.LONG:  return "LONG";
        case ISignal.SHORT: return "SHORT";
        case ISignal.FLAT:  return "FLAT";
        default: return "NO SIGNAL";
        }
    }
    
    /**
     * is there a Position Open?
     * @return boolean
     *         true if there an open position (long/short)
     *         false if not
     */
    public boolean isPositionOpen(){
        if (currentPosition()!=ISignal.FLAT)
            return false;
        else
            return true;
    }
    
    /**
     * Returns string signal, uppercase
     * @return
     */
    public String getStrSignal() {
        switch (currentSignal) {
            case ISignal.BUY:       return "BUY";
            case ISignal.SELL:      return "SELL";
            case ISignal.COVER:     return "COVER";
            case ISignal.SHORT:     return "SHOR";
            case ISignal.FLAT:      return "FLAT";
            case ISignal.HOLD:      return "HOLD";
            case ISignal.NOSIGNAL:  return "NOSIGNAL";
            case ISignal.LONG:      return "LONG";
            case ISignal.FAIL:      return "Operation Failed";
            case ISignal.NOCASH:    return "Out of Cash!";
            default:                return "";
        }
    };
    
    /**
     * Gets currentSignal
     * @return int
     */
    public int getSignal() {       
        return currentSignal;
    }

    /**
     * No signal
     */
    public void NoSignal(){
        currentSignal = ISignal.NOSIGNAL;
    }


    /**
     * Override Buy, avoid time parameter, when use daily frame
     * @param buyPrice
     * @param buyDate
     * @param qty
     */
    public void Buy(double buyPrice,int buyDate,int qty){
        Buy(buyPrice,buyDate,0,qty);
    }

    /**
     * Override Cover, avoid time parameter, when use daily frame
     * @param buyPrice
     * @param buyDate
     * @param qty
     */
    public void Cover(double coverPrice,int coverDate,int qty){
        Cover(coverPrice,coverDate,0,qty);
    }

    
    /**
     * Buy
     * @param buyPrice double
     * @param qty int
     */
    public void Buy(double buyPrice,int buyDate,int buyTime,int qty) {
        if (qty>0){
            if (!openLong) {
                //  set position
                openLong    = true;
                openShort   = false;
                //          
                double amount = (buyPrice * qty);
                if (tAccount.withdraw(amount)){
                    //  buy
                    currentSignal = ISignal.BUY;
                    portfolio.openLongTrade(buyDate,buyTime,buyPrice,qty);
                } else {
                    //  cannot buy, cash missing
                    if (verbose)
                        System.out.println("Out of cash on "+Common.formatDate(buyDate)+" buy at "+buyPrice+" but account cash is "+tAccount.getCash());
                    currentSignal = ISignal.NOCASH;
                }
            }
        } else {
            // qty=0
            currentSignal = ISignal.FAIL;
            if (verbose)
                System.out.println("Not enought money to reach qty>0, increase your trading account size or you will miss some trades!");
        }
    } 


    
    /**
     * Override Sell, avoid time parameter, when use daily frame
     * @param sellPrice
     * @param sellDate
     * @param qty
     */
    public void Sell(double sellPrice,int sellDate,int qty){
        Sell(sellPrice,sellDate,0,qty);
    }

    /**
     * Override Short, avoid time parameter, when use daily frame
     * @param sellPrice
     * @param sellDate
     * @param qty
     */
    public void Short(double shortPrice,int shortDate,int qty){
        Short(shortPrice,shortDate,0,qty);
    }

    
    /**
     * Short
     * @param shortPrice double
     * @param qty int
     */
    public void Short(double shortPrice,int shortDate,int shortTime,int qty) {
        if (qty>0){
            if (!openShort) {
                //  set position
                openLong    = false;
                openShort   = true;
                //          
                double amount = (shortPrice * qty);
                if (tAccount.withdraw(amount)){
                    //  short
                    currentSignal = ISignal.BUY;
                    portfolio.openShortTrade(shortDate,shortTime,shortPrice,qty);
                } else {
                    //  cannot short, cash missing
                    if (verbose)
                        System.out.println("Out of cash on "+Common.formatDate(shortDate)+" short at "+shortPrice+" but account cash is "+tAccount.getCash());
                    currentSignal = ISignal.NOCASH;
                }
            }
        } else {
            // qty=0
            currentSignal = ISignal.FAIL;
            if (verbose)
                System.out.println("Not enought money to reach qty>0, increase your trading account size or you will miss some trades!");
        }
    } 


    
    
    /**
     * Sell
     * @param sellPrice double
     * @param qty int
     */
    public void Sell(double sellPrice,int sellDate,int sellTime,int qty) {
        if (openLong){ // sell only if there is an openposition opened
            // set position
            openLong    = false;
            openShort   = false;
            // 
            double amount = (sellPrice * qty);
            //  do not check because we supposed to have a success in deposit money (read give money to bank) :-)
            tAccount.deposit(amount);
            portfolio.closeLongTrade(sellDate,sellTime,sellPrice,qty);
            // sell
            currentSignal = ISignal.SELL;
        }
    }

    /**
     * Cover
     * @param coverPrice double
     * @param qty int
     */
    public void Cover(double coverPrice,int coverDate,int coverTime,int qty) {
        if (openShort){ // cover only if there is a position opened
            // set position
            openLong    = false;
            openShort   = false;
            // 
            double amount = (coverPrice * qty);
            //  do not check because we supposed to have a success in deposit money (read give money to bank) :-)
            tAccount.deposit(amount);
            portfolio.closeShortTrade(coverDate,coverTime,coverPrice,qty);
            // sell
            currentSignal = ISignal.SELL;
        }
    }


    /**
     * Hold
     */
    public void Hold() {
        currentSignal = ISignal.HOLD;
    }

    /**
     * Flat
     */
    public void Flat() {
        currentSignal = ISignal.FLAT;
    }

    /**
     * shows portfolio contents, usefull for debug purpose.
     */
    public void showPortfolio(){       
        LinkedList p = portfolio.getPortfolioEntries();
        for (int i=0;i<p.size();i++){
            Trade po = (Trade) p.get(i);
            System.out.println(po.getPositionType().toString()+","+po.getStartDate()+","+po.getStartPrice()+","+po.getStartQty()+","+po.getStatus());
        }
    }
    
    /**
     * Reverse position
     * @param positionToReverse is the position that should be reversed
     * @param price
     * @param date
     * @param time
     * @param qty
     */
    public void reverse(int positionToReverse,double price,int date,int time,int qty){
        if (positionToReverse == ISignal.SHORT){
            Cover(price,date,time,qty);
            Buy(price,date,time,qty);
        }
        if (positionToReverse == ISignal.LONG){
            Sell(price,date,time,qty);
            Short(price,date,time,qty);            
        }
    }
   
    /**
     * Reverse position ( overrides reverse for daily signals ) 
     * @param positionToReverse is the position that should be reversed
     * @param price
     * @param date
     * @param qty
     */
    public void reverse(int positionToReverse,double price,int date,int qty){
        if (positionToReverse == ISignal.SHORT){
            Cover(price,date,qty);
            Buy(price,date,qty);
        }
        if (positionToReverse == ISignal.LONG){
            Sell(price,date,qty);
            Short(price,date,qty);            
        }
    }
       
  
    /**
     * Is there a Long position opened?
     * @return
     */
    public boolean isLong(){
        return openLong;
    }
    
    /**
     * Is there a Short position opened?
     * @return
     */
    public boolean isShort(){
        return openShort;
    }
    
    /**
     * Is flat?
     * @return
     */
    public boolean isFlat(){
        if ((!openShort)&&(!openLong))
            return true;
        else
            return false;
    }

    
    
}
