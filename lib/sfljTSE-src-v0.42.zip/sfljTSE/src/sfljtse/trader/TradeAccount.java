/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.trader;

import sfljtse.utils.Common;

/**
 * @title		: TradeAccount     
 * @description	: 
 * @date		: 14-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class TradeAccount extends Account{

    protected Commission commission;
    private   double capitalGain = 0; 
    
    /**
     * Constructor
     * @param amount double 
     * @param commission Commission
     */
    public TradeAccount(double amount,Commission commission){
        this.deposit(amount);
        this.commission = commission;
    }
    
    /**
     * Sets Capital Gain tax
     * @param taxPercent
     */
    public void setCapitalGainTax(double taxPercent){
        if ((taxPercent>0)||(taxPercent<100))
            capitalGain = taxPercent;
        else
            capitalGain = Math.abs(taxPercent % 100);
    }
    
    /**
     * Gets capital gain tax
     * @return double percentage
     */
    public double getCapitalGainTaxPercent(){
        return capitalGain;
    }
    
    /**
     * Return a capital gain tax to pay on given amount of gain 
     * @param amount
     * @return
     */
    public double getCapitalGainTax(double amount){
        return (amount/100)*this.getCapitalGainTaxPercent();
    }
    
    /**
     * Gets max quantity to invest all capital, calculated on cash on account
     * @param currentPrice
     * @return
     */
    public int investAllCapital(double currentPrice){
        return (int) (getCash() / currentPrice);
    }

    /**
     * Gets max quantity to invest given amount 
     * @param currentPrice
     * @param amount
     * @return
     */
    public int investFor(double currentPrice,double amount){
        return (int) (amount/currentPrice);
    }

    /**
     * Gets quantity for a given percent of current account cash
     * @param currentPrice
     * @param percent
     * @return
     */
    public int investPercentOf(double currentPrice,int percent){
        return (int) (this.getCashPercent(percent)/currentPrice);
    }
    
    /**
     * Returns commission value for a given amount
     * @param price
     * @param qty
     * @return
     */
    public double calcCommission(double amount){
        double comm = (amount/(double)100)*commission.getPercentage();
        if (comm<commission.getBase())
                comm = commission.getBase();
        if (comm>commission.getUpTo())
                comm = commission.getUpTo();        
        return comm + commission.getSlipPage();
    }
    
    
    /**
     * Returns slippage!
     * @return
     */
    public double calcSlipPage(){
        return commission.getSlipPage();
    }
    
}
