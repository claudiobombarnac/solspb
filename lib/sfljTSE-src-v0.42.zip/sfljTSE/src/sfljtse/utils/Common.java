/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.utils;

import java.io.File;
import java.io.FilenameFilter;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import sfljtse.settings.Settings;
 
/**
 * @title		: Common       
 * @description	:  
 * @date		: 8-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Common {

    /**
     * Format ISO date to dd/mm/yyyy
     * @param isoData
     * @return
     */
    public static String formatDate(int isoDate){
        
        String isoFormat = ""+isoDate;
        
        String yyyy = isoFormat.substring(0,4);
        String mm   = isoFormat.substring(4,6);
        String dd   = isoFormat.substring(6,8);
        
        return dd+"/"+mm+"/"+yyyy;
    }
    
    /**
     * get data and convert it to iso format
     * @param date
     * @return
     */
    public static String dateToIso(String date){
        
        String dd   = date.substring(0,2);
        String mm   = date.substring(3,5);
        String yyyy = date.substring(6,10);
        
        return yyyy+mm+dd;
    }
    
    /**
     * Returns a String that contains a ISO data
     * @param date
     * @return
     */
    public static String Date2ISO(Date date) {
        String timePattern = "yyyyMMdd";
        SimpleDateFormat formatter = new SimpleDateFormat(timePattern);

        return formatter.format(date);
    }
    
    
    /**
     * Converts ISO formated dates to Java Date
     * @param dateStr
     * @return Date
     */
    public static Date ISO2Date(String dateStr) {
        String timePattern = "";

        // select the time pattern to use:
        if (dateStr.length() == 8) {
            timePattern = "yyyyMMdd";
        } else if (dateStr.length() == 12) {
            timePattern = "yyyyMMdd";
        } else if (dateStr.length() == 13) {
            timePattern = "yyyyMMdd";
        } else if (dateStr.length() == 14) {
            timePattern = "yyyyMMdd";
        } else if (dateStr.length() == 15) {
            timePattern = "yyyyMMdd";
        } else if (dateStr.length() > 8 && dateStr.charAt(8) == 'T') {
            timePattern = "yyyyMMdd";
        } else {
            timePattern = "yyyyMMdd";
        }

        // Format the current time.
        SimpleDateFormat formatter = new SimpleDateFormat(timePattern);

        Date d = null;

        try {
            d = formatter.parse(dateStr, new ParsePosition(0));
        } catch (NullPointerException e) {
            return null;
        }
        return d;
    }
    
    
    /**
     * Converts a string to a date from a given data format
     * @param strDate
     * @param strFormat
     * @return
     * @throws Throwable
     */
    public static Date stringToDate(String strDate,String strFormat,Locale locale)throws Throwable{
        DateFormat myDateFormat = new SimpleDateFormat(strFormat,locale);
        Date myDate = null;
        myDate = myDateFormat.parse(strDate);
        return myDate;
    }
    
    /**
     * Returns the first jarFileName in the given directory
     * @param myDir String
     * @return String jarFileName
     */
    public static String getJarFileName(String myDir){
        File dir = new File(myDir);
        FilenameFilter filter = new FilenameFilter(){
            public boolean accept(File dir, String name) {
                return name.contains(".jar");
            }
        };      
        
        String[] children = dir.list(filter);
        if (children == null) {
            return "";
        } else {
            for (int i=0; i<children.length; i++) {
                // Get filename of file or directory
                String filename = children[i];
                // return at first...
                return filename;
            }
        }
        return "";
    }
    
    /**
     * Rounds a double with given decimals, rounds at half up.
     * @param num
     * @param decimals
     * @return double
     */ 
    public static double round(double num,int decimals){
        int decimalPlace = decimals;
        BigDecimal bd = new BigDecimal(num);
        bd = bd.setScale(decimalPlace,BigDecimal.ROUND_HALF_UP);
        return bd.doubleValue();
    }

    
}
