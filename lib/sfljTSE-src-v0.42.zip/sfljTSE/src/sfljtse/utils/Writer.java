/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @title		: FileWriter       
 * @description	: Writes on file
 * @date		: 19-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Writer {
    private File outputFile;
    private FileWriter out;
    
    /**
     * Constructor 1
     * @param fileClassName
     * @throws IOException
     */
    public Writer(String fileName) throws IOException {
        outputFile  = new File(fileName);
        out         = new FileWriter(outputFile);
        out.flush();

    }

 
    /**
     * Constructor 2
     * @param fileClassName
     * @param myPath
     * @throws IOException
     */
    public Writer(String fileName,String myPath) throws IOException {
        outputFile  = new File(myPath + fileName);
        out         = new FileWriter(outputFile);
        out.flush();

    }  

    public void write(){
        System.out.println();
    }
    
    public void write(String txt){
        try {
            out.write(txt);
        } catch (IOException e) {
        }
    }
        
    /**
     * Close file
     */
    public void close() throws IOException{
        out.close();
    }

    

}

