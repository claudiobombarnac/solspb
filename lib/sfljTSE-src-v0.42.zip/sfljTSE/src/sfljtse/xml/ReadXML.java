/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.xml;

import java.io.File;
import java.util.ArrayList;
import org.w3c.dom.*; 

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;


/**
 * 
 * @title       : ReadXML       
 * @description : Simple XML parser, can reads inside node by new methods
 * @date        : 26-lug-2005  modified on 07.09.2005 
 * @author      : Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class ReadXML {
        
    private Document doc;
    private NodeList listOfElements;

    /**
     * Constructor 1
     * @param xmlFile
     */
    public ReadXML(String xmlFile){
        File f = new File(xmlFile);
        if (f.exists())
            commonConstructor(xmlFile);
        else {
            System.out.println("Cannot load file "+xmlFile+" !");
            System.exit(1);
        }
    }

    /**
     * Loads document
     * @param xmlFile String
     */
    private void commonConstructor(String xmlFile){
        try {    
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            doc = docBuilder.parse (new File(xmlFile));
            //  normalize text representation
            doc.getDocumentElement ().normalize ();
        }catch (Throwable t) {
            System.out.println("We gotcha error in XML configuration file, give it a look!");
            t.printStackTrace ();
        }               
    }
    
    
        
    /**
     * Returns array of XML_tags
     * @param headTag String
     * @param leafTag String
     * @return String[]
     * 
     * [code]
     *      
     *  ReadXML xml = new ReadXML("sfljTSE-config.xml");
     *  String[] out = xml.getValuesOf("SYMBOLS","SYMBOL");
     *  for (int i=0;i<out.length;i++)
     *      System.out.println("DEBUG="+out[i]);
     * 
     * [/code]
     * 
     */
    public String[] getValuesOf(String headTag,String leafTag){
        // gets list of items
        listOfElements = doc.getElementsByTagName(headTag);
        Node myNode = listOfElements.item(0);
        int len = myNode.getChildNodes().getLength();
        ArrayList<String> ret = new ArrayList<String>();
        for (int i=0;i<len;i++){
            Node tmp = myNode.getChildNodes().item(i);
            if (tmp.getNodeName().equalsIgnoreCase(leafTag))
                ret.add(tmp.getTextContent());
        }// end for
        String[] obj = new String[ret.size()];
        return ret.toArray(obj);
    }



    /**
     * Gets value from a given head and leaf Tag
     * @param headTag String
     * @param leafTag String
     * @return String, "" if some error occours
     */
    public String getValueOf(String headTag,String leafTag){
        String ret = "";
        try {
            // gets list of items
            listOfElements = doc.getElementsByTagName(headTag);
            for(int s=0; s<listOfElements.getLength(); s++){
                Node myNode = listOfElements.item(s);
                if(myNode.getNodeType() == Node.ELEMENT_NODE){
                    Element myElement = (Element)myNode; 

                    NodeList firstTableList  = myElement.getElementsByTagName(leafTag);
                    Element firstElement = (Element)firstTableList.item(0);

                    NodeList textFNList = firstElement.getChildNodes();
                    ret=((Node)textFNList.item(0)).getNodeValue().trim();
                }
            }
            return ret;
        } catch (Exception e){
            // gotcha some fucking error!
            return "";
        }
    }  
    
    
    /**
     * Gets a value of a given headTag and LeafTag starting from lof Nodelist
     * @param lof
     * @param headTag
     * @param leafTag
     * @return
     */
    public String getValueOfNode(NodeList lof,String headTag,String leafTag){
        String ret = "";
        try {
            // gets list of items
            //listOfElemetsof = doc.getElementsByTagName(headTag);
            for(int s=0; s<lof.getLength(); s++){
                Node myNode = lof.item(s);
                if(myNode.getNodeType() == Node.ELEMENT_NODE){
                    Element myElement = (Element)myNode; 
                  
                    NodeList firstTableList  = myElement.getElementsByTagName(leafTag);
                    Element firstElement = (Element)firstTableList.item(0);
                    
                    NodeList textFNList = firstElement.getChildNodes();
                    ret=((Node)textFNList.item(0)).getNodeValue().trim();
                }
            }
            return ret;
        } catch (Exception e){
            // gotcha some fucking error!
            e.printStackTrace();
            return "";
        }
    }  


    /**
     * Returns the Node that is identified by headTag and subTag
     * The subTag will be the new root of a new node block
     * @param headTag
     * @param subTag
     * @return NodeList
     */
    public NodeList getTreeNodeOf(String headTag,String subTag){
        try {
            // gets list of items
            listOfElements = doc.getElementsByTagName(headTag);
            for(int s=0; s<listOfElements.getLength(); s++){
                Node myNode = listOfElements.item(s);
                if(myNode.getNodeType() == Node.ELEMENT_NODE){
                    Element myElement = (Element)myNode; 
                    NodeList firstTableList  = myElement.getElementsByTagName(subTag);
                    return firstTableList;
                }
            }
        } catch (Exception e){
            // gotcha some fucking error!
            return null;
        }
        return null;
    }      
    
    
}
