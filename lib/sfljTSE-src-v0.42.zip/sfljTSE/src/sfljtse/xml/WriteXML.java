/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.xml;

import sfljtse.utils.Writer;

/**
 * @title		: WriteXML       
 * @description	:  
 * @date		: 26-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class WriteXML {

    private Writer xml;
    
    public WriteXML(String fileName) throws Throwable{
        xml = new Writer(fileName);
    }
    
    
    /**
     * Writes XML head
     */
    public void writeHead(){
        xml.write("<?xml version=\"1.0\"?>");
        xml.write("<sfljTSE>");
    }
    
    /**
     * writeTagValue, tag must be passed without "<" ">"
     * @param tagName String
     * @param value String
     * @param comment String
     */
    public void writeTagValue(String tagName,String value,String comment){
        xml.write("<!-- "+comment+" -->");
        xml.write("<"+tagName+">");
        xml.write(value);
        xml.write("</"+tagName+">");
    }

    /**
     * Writes tag value
     * @param tagName String
     * @param value String
     */
    public void writeTagValue(String tagName,String value){
        xml.write("<"+tagName+">");
        xml.write(value);
        xml.write("</"+tagName+">");
    }

    /**
     * Writes open head tag
     * @param headTag
     */
    public void openHeadTag(String headTag){
        xml.write("<"+headTag+">");
    }
    
    /**
     * Writes close head tag
     * @param headTag
     */
    public void closeHeadTag(String headTag){
        xml.write("</"+headTag+">");
    }
    
    /**
     * Close XML file
     * @throws Throwable 
     */
    public void closeXMLfile() throws Throwable{
        xml.write("</sfljTSE>");
        xml.close();
    }
    
}
