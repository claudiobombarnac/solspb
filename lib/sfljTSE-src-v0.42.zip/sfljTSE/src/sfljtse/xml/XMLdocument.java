/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.xml;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;


/**
 * @title       : XMLdocument       
 * @description :   
 * @date        : 26-lug-2005   
 * @author      : Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class XMLdocument {

        
    /**
     * This method gets an XML document from the given URL.
     */
    public static Document getDocument( DocumentBuilder db, String urlString ) {
       try {
          URL url = new URL( urlString );
          try {
             URLConnection URLconnection = url.openConnection();
             HttpURLConnection httpConnection = (HttpURLConnection) URLconnection;
             int responseCode = httpConnection.getResponseCode();
             if ( responseCode == HttpURLConnection.HTTP_OK) {
                InputStream in = httpConnection.getInputStream();
                try {
                   Document doc = db.parse( in );
                   return doc;
                   } catch( org.xml.sax.SAXException e ) {
                      //e.printStackTrace();
                   }
             }// else
              //  System.out.println( "HTTP connection response != HTTP_OK" );
          } catch ( IOException e ) {
             //e.printStackTrace();
          } // catch
       } catch ( MalformedURLException e ) {
          //e.printStackTrace();
       } // catch
       return null;
    } // getDocument

    /**
     * This method gets an XML document from the given FILE.
     */
    public static Document getFileDocument( DocumentBuilder db, File filePath) {
        try {
            Document doc = db.parse( filePath);
            return doc;
        } catch (SAXException e) {
            //e.printStackTrace();
        } catch (IOException e) {
            //e.printStackTrace();
        }
       return null;
    } 
    
    
    
}
