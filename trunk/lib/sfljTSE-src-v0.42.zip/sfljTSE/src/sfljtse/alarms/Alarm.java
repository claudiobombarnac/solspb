/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.alarms;

import sfljtse.alarms.model.Sms;


/**
 * @title		: Alarm       
 * @description	: Manages alarms due to some signals or whatelse  
 * @date		: 28-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Alarm {

    private String systemName   = "";
    private String alarmStr     = "";
    
    // alarm's type
    public Mail   mail    = new Mail();
    public Sms    sms     = new Sms();
    public Win    win     = new Win();
    public Sound  sound   = new Sound();
    
    /**
     * Constructor 1
     * @param alarmStr
     */
    public Alarm(String alarmStr){
        this.alarmStr = alarmStr;
    }
    
    /**
     * Constructor 2
     * @param systemName
     * @param alarmStr
     */
    public Alarm(String systemName,String alarmStr){
        this.alarmStr = alarmStr;
        this.systemName = systemName;
    }
    
}
