/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.systems;

import sfljtse.systems.model.ASystem;
import sfljtse.systems.model.ISystem;

/**
 * @title		: SystemTemplate       
 * @description	:  
 * @date		: 29-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class SystemTemplate extends ASystem implements ISystem {
    
    /**
     * Constructor 1
     */
    public SystemTemplate() {
        this.systemName         = "template";
        this.systemDescription  = "An empty system";
        this.systemAuthor       = "sfl";
        this.showInfo();        
    }

    /**
     * Constructor 2
     * @param configFile
     */
    public SystemTemplate(String configFile) {
        super(configFile);
        // TODO Auto-generated constructor stub
    }

    /**
     * System's engine
     */
    public void engine(){
        // wrote here your system's logic
    }
    
}
