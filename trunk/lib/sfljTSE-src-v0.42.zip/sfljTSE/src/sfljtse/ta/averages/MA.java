/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.ta.averages;

import sfljtse.ta.averages.model.AbstractMA;

/**
 * @title		: MA       
 * @description	: Links SMA to keep compability with previus version,
 *                use SMA if possible instead of MA.
 * @date		: Aug 18, 2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 * @see SMA class
 */
public class MA extends AbstractMA {

    public MA(double[] value, int periods){
        super(value,periods);
        this.ma = new SMA(value,periods).ma;
    }
    
}
