/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.ta.averages;

import sfljtse.ta.averages.model.AbstractMA;
import sfljtse.ta.averages.model.IMA;

/**
 * @title		: SMA       
 * @description	: Simple Moving Average 
 * @date		: 18-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class SMA extends AbstractMA implements IMA {
    
    public SMA(double[] value, int periods) {
        super(value, periods);
        calc();
    }

    /**
     * Calculate the simple moving average
     */
    public void calc(){
        double sum = 0;
        int size = value.length;
        if (periods>size){
            for (int i=0;i<size;i++)
                ma[i] = 0.0;
        } else {
            for (int i=periods;i<size;i++){
                sum = 0;
                for (int p=0;p<periods;p++){
                    sum += value[i-p];
                }
                ma[i] = sum/periods;
            }
        }  
    }
    
}
