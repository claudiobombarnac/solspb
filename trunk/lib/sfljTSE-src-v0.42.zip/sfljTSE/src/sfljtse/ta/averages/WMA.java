/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljtse.
 * 
 * sfljtse is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljtse is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.ta.averages;

import sfljtse.ta.averages.model.AbstractMA;
import sfljtse.ta.averages.model.IMA;

/**
 * @title		: WMA       
 * @description	: Weighted Moving Average  
 * @date		: Sep 5, 2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class WMA extends AbstractMA implements IMA{

    public WMA(double[] value, int periods) {
        super(value, periods);
        calc();
    }

    /**
     * Calculate Weighted Moving Average
     * 
     * Formula is: 
     * WMA = ( PRICE * n + PRICE(1) * n-1 + ... PRICE(n-1) * 1) / ( n * (n + 1) / 2 )
     * where n = periods
     * 
     * TODO: CHECK IT OUT IS WRONG!!
     * 
     */
    public void calc() {
        int size = value.length;
        double sum = 0;
        if(periods>size) {
            for (int i=0;i<size;i++)
                ma[i] = 0.0;   
        } else {   
            for (int i=periods;i<size;i++){
                sum = 0;
                for (int p=0;p<periods;p++){
                    sum += value[i-p] * periods-p;
                }
                ma[i] = sum/(periods*(periods+1)/2);
            }
        }        
    }

}
