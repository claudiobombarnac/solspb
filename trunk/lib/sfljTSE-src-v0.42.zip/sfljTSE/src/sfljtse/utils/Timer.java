/*
 * 
 * SFL java Trading System Enviroment
 * Copyright (C) 2005 Alberto Sfolcini <a.sfolcini@gmail.com>
 * 
 * This file is a part of sfljTSE.
 * 
 * sfljTSE is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * sfljTSE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */
package sfljtse.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * @title		: Timer       
 * @description	:  
 * @date		: 8-lug-2005   
 * @author		: Alberto Sfolcini  <a.sfolcini@gmail.com>
 */
public class Timer {

    private long startTime;
    private String strDateFormat = "HH:mm:ss:SS";
    
    
    /**
     * Constructor 
     */
    public Timer(){   
    }
    
    /**
     * Constructor 2
     * @param dateFormat String
     */
    public Timer(String dateFormat){
        this.strDateFormat = dateFormat;
    }
    
    /**
     * Start Timer
     */
    public void startTimer(){
        startTime = System.currentTimeMillis();        
    }
    
    /**
     * Stops timer and returns elapsed time
     * @return String time elapsed
     */
    public String stopTimer(){
        long currentTime = System.currentTimeMillis();
        long elapsed = currentTime - startTime;
        SimpleDateFormat dateFormat = new SimpleDateFormat(strDateFormat);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        return dateFormat.format(new Date(elapsed))+" ("+strDateFormat+")";        
    }
    
}
